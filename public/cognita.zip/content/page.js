// content/page.js — يعمل على كل الصفحات
// (1) مصحّح اتجاه اللغة العربية RTL  (2) مزوّد نص الصفحة/التحديد لأدوات اللوحة
(() => {
  if (window.__cognitaPage) return;
  window.__cognitaPage = true;

  const AR = /[؀-ۿݐ-ݿࢠ-ࣿﭐ-﷿ﹰ-﻿]/;
  const host = location.hostname;
  const SEL = "p,div,span,li,td,th,h1,h2,h3,h4,h5,h6,a,blockquote,figcaption,label,button,article,section,dd,dt,summary,caption";
  let observer = null, timer = null;

  // يضع dir="auto" على العناصر التي تحتوي نصاً عربياً → المتصفح يضبط الاتجاه تلقائياً
  function markArabic(root) {
    if (!root || !root.querySelectorAll) return;
    root.querySelectorAll(SEL).forEach((el) => {
      if (el.dataset.cognitaDir) return;
      const t = el.textContent;
      if (t && AR.test(t)) { el.setAttribute("dir", "auto"); el.dataset.cognitaDir = "1"; }
    });
  }
  function enableRtl() {
    document.documentElement.setAttribute("data-cognita-rtl", "on");
    markArabic(document.body || document.documentElement);
    if (!observer) {
      observer = new MutationObserver(() => {
        clearTimeout(timer);
        timer = setTimeout(() => markArabic(document.body || document.documentElement), 350);
      });
      observer.observe(document.documentElement, { childList: true, subtree: true });
    }
  }
  function disableRtl() {
    document.documentElement.removeAttribute("data-cognita-rtl");
    if (observer) { observer.disconnect(); observer = null; }
    document.querySelectorAll("[data-cognita-dir]").forEach((el) => {
      el.removeAttribute("dir"); delete el.dataset.cognitaDir;
    });
  }

  // تطبيق تلقائي إذا كان مفعّلاً لهذا الموقع (أو عالمياً)
  chrome.storage.local.get(["rtlSites", "rtlGlobal"]).then((d) => {
    if (d.rtlGlobal || (d.rtlSites || {})[host]) enableRtl();
  }).catch(() => {});

  const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));

  // قارئ مركّز: يستخرج المقال ويعرضه في طبقة نظيفة (RTL تلقائي)
  function toggleReader() {
    const ex = document.getElementById("cognita-reader");
    if (ex) { ex.remove(); return false; }
    let best = null, score = 0;
    document.querySelectorAll("article,main,[role=main],.post,.article,.content,#content,.entry,.story").forEach((el) => {
      const s = (el.innerText || "").length; if (s > score) { score = s; best = el; }
    });
    const scope = best || document.body;
    const parts = [];
    scope.querySelectorAll("h1,h2,h3,h4,p,li,blockquote").forEach((el) => {
      const t = (el.innerText || "").trim();
      const tag = el.tagName.toLowerCase();
      if (t.length > 1) parts.push(`<${tag}>${esc(t)}</${tag}>`);
    });
    if (!document.getElementById("cognita-reader-style")) {
      const st = document.createElement("style"); st.id = "cognita-reader-style";
      st.textContent = `#cognita-reader{position:fixed;inset:0;z-index:2147483647;background:#fbfaf7;overflow:auto;font-family:system-ui,'Segoe UI',Tahoma,sans-serif}
      #cognita-reader .cr-bar{position:sticky;top:0;display:flex;justify-content:space-between;align-items:center;background:#fff;border-bottom:1px solid #e3e8f1;padding:12px 18px;font-weight:700;color:#0f1729}
      #cognita-reader .cr-bar button{background:linear-gradient(135deg,#6366f1,#a855f7);color:#fff;border:none;border-radius:8px;padding:7px 15px;cursor:pointer;font:inherit;font-weight:700}
      #cognita-reader .cr-body{max-width:720px;margin:0 auto;padding:34px 22px 90px;line-height:2;color:#1f2937;font-size:19px}
      #cognita-reader .cr-body h1,#cognita-reader .cr-body h2,#cognita-reader .cr-body h3,#cognita-reader .cr-body h4{color:#0f1729;line-height:1.4;margin:26px 0 10px}
      #cognita-reader .cr-body p,#cognita-reader .cr-body li{margin:0 0 16px}`;
      document.documentElement.appendChild(st);
    }
    const ov = document.createElement("div"); ov.id = "cognita-reader";
    ov.innerHTML = `<div class="cr-bar"><span>📖 القارئ المركّز — Cognita</span><button id="cr-x">✕ إغلاق</button></div><article class="cr-body" dir="auto">${parts.join("") || "<p>لا يوجد محتوى نصّي.</p>"}</article>`;
    document.documentElement.appendChild(ov);
    ov.querySelector("#cr-x").onclick = () => ov.remove();
    return true;
  }

  // وضع الوصول/التباين العالي
  function toggleContrast() {
    if (document.documentElement.hasAttribute("data-cognita-contrast")) {
      document.documentElement.removeAttribute("data-cognita-contrast"); return false;
    }
    if (!document.getElementById("cognita-contrast-style")) {
      const st = document.createElement("style"); st.id = "cognita-contrast-style";
      st.textContent = `html[data-cognita-contrast] body, html[data-cognita-contrast] *{background-color:#000 !important;color:#fff !important;border-color:#777 !important;text-shadow:none !important}
      html[data-cognita-contrast] a, html[data-cognita-contrast] a *{color:#ffd54a !important;text-decoration:underline !important}
      html[data-cognita-contrast] input,html[data-cognita-contrast] textarea{background:#111 !important}`;
      document.documentElement.appendChild(st);
    }
    document.documentElement.setAttribute("data-cognita-contrast", "1");
    return true;
  }

  function extractLinks() {
    const seen = new Set(), out = [];
    document.querySelectorAll("a[href]").forEach((a) => {
      const href = a.href;
      if (!/^https?:/.test(href) || seen.has(href)) return;
      seen.add(href);
      out.push({ text: (a.innerText || "").trim().slice(0, 80) || href, href });
    });
    return out.slice(0, 300);
  }

  chrome.runtime.onMessage.addListener((msg, _s, reply) => {
    if (msg?.type === "READER_MODE") { reply?.({ on: toggleReader() }); return true; }
    if (msg?.type === "CONTRAST_MODE") { reply?.({ on: toggleContrast() }); return true; }
    if (msg?.type === "EXTRACT_LINKS") { reply?.({ links: extractLinks() }); return true; }
    if (msg?.type === "RTL_TOGGLE") {
      chrome.storage.local.get("rtlSites").then((d) => {
        const sites = d.rtlSites || {};
        const on = !sites[host];
        if (on) { sites[host] = true; enableRtl(); } else { delete sites[host]; disableRtl(); }
        chrome.storage.local.set({ rtlSites: sites });
        reply?.({ ok: true, on });
      });
      return true;
    }
    if (msg?.type === "RTL_STATE") {
      chrome.storage.local.get(["rtlSites", "rtlGlobal"]).then((d) =>
        reply?.({ on: Boolean(d.rtlGlobal || (d.rtlSites || {})[host]), host }));
      return true;
    }
    if (msg?.type === "GET_PAGE_TEXT") {
      const text = (document.body ? document.body.innerText : "").replace(/\n{3,}/g, "\n\n").trim().slice(0, 12000);
      reply?.({ text, title: document.title, url: location.href });
      return true;
    }
    if (msg?.type === "GET_SELECTION") {
      reply?.({ text: String(window.getSelection()).trim(), url: location.href, title: document.title });
      return true;
    }
  });
})();
