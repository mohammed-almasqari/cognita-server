// content/content.js — يُحقن في مواقع النماذج (مستقل بلا imports)
// يضيف زراً عائماً عند تحديد نص، ويُدرج البرومبت في الحقل النشط عند الطلب.
(() => {
  if (window.__cognitaInjected) return;
  window.__cognitaInjected = true;

  let lastSelection = "";
  let btn = null;

  function getActiveField() {
    const ae = document.activeElement;
    if (ae && (ae.tagName === "TEXTAREA" || ae.isContentEditable)) return ae;
    // محاولة العثور على أبرز حقل إدخال في صفحات النماذج
    return (
      document.querySelector('textarea:not([readonly])') ||
      document.querySelector('[contenteditable="true"]') ||
      document.querySelector('div[role="textbox"]')
    );
  }

  function insertIntoField(text) {
    const f = getActiveField();
    if (!f) return false;
    f.focus();
    if (f.tagName === "TEXTAREA" || f.tagName === "INPUT") {
      const start = f.selectionStart ?? f.value.length;
      const end = f.selectionEnd ?? f.value.length;
      f.value = f.value.slice(0, start) + text + f.value.slice(end);
      f.dispatchEvent(new Event("input", { bubbles: true }));
    } else if (f.isContentEditable || f.getAttribute("role") === "textbox") {
      document.execCommand("insertText", false, text);
      f.dispatchEvent(new Event("input", { bubbles: true }));
    }
    return true;
  }

  function showButton(x, y) {
    if (!btn) {
      btn = document.createElement("div");
      btn.id = "cognita-fab";
      btn.innerHTML = "✦ حسّن مع Cognita";
      btn.addEventListener("mousedown", (e) => {
        e.preventDefault();
        chrome.runtime.sendMessage({ type: "PUSH_INTENT", action: "prompt", text: lastSelection });
        chrome.runtime.sendMessage({ type: "OPEN_PANEL" });
        hideButton();
      });
      document.body.appendChild(btn);
    }
    btn.style.top = `${y + window.scrollY + 8}px`;
    btn.style.left = `${x + window.scrollX}px`;
    btn.classList.add("show");
  }
  function hideButton() { btn && btn.classList.remove("show"); }

  document.addEventListener("mouseup", (e) => {
    if (btn && btn.contains(e.target)) return;
    const sel = window.getSelection().toString().trim();
    if (sel && sel.length > 1) {
      lastSelection = sel;
      showButton(e.clientX, e.clientY);
    } else {
      hideButton();
    }
  });
  document.addEventListener("scroll", hideButton, true);

  // استقبال أمر الإدراج من اللوحة
  chrome.runtime.onMessage.addListener((msg, _s, reply) => {
    if (msg?.type === "INSERT_TEXT") {
      const ok = insertIntoField(msg.text || "");
      reply?.({ ok });
    }
    return true;
  });
})();
