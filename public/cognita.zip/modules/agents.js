// modules/agents.js — وحدة توجيه الوكلاء (منشئ بصري + تشغيل خطوة بخطوة)
import { db, uid, now } from "../shared/db.js";
import { $, $$, esc, toast } from "../shared/util.js";
import { callModel, PROVIDERS } from "../shared/providers.js";
import { settings } from "../shared/store.js";
import { requirePro, FEATURE } from "../shared/license.js";

const KIND = {
  input: { label: "مُدخل", icon: "⌗", color: "n", desc: "النص الابتدائي للسلسلة" },
  prompt: { label: "خطوة نموذج", icon: "✦", color: "a", desc: "استدعاء نموذج ببرومبت" },
  fetch: { label: "أداة: جلب رابط", icon: "🌐", color: "p", desc: "جلب نص صفحة ويب" },
  condition: { label: "شرط", icon: "◈", color: "s", desc: "تابع فقط إذا تحقّق" },
  output: { label: "مخرَج", icon: "▣", color: "n", desc: "النتيجة النهائية" },
};

// نماذج وكلاء جاهزة (تعمل مجاناً — تحميل بنقرة ثم تعديل/تشغيل)
const AGENT_TEMPLATES = [
  { name: "ملخّص ونقاط رئيسية", nodes: [
    { kind: "input", config: {} },
    { kind: "prompt", config: { system: "أنت محلّل خبير دقيق.", template: "لخّص النص التالي في فقرة موجزة، ثم اذكر أهم 5 نقاط على شكل قائمة:\n\n{{input}}" } },
    { kind: "output", config: { template: "{{last}}" } } ] },
  { name: "كاتب منشور اجتماعي", nodes: [
    { kind: "input", config: {} },
    { kind: "prompt", config: { system: "أنت كاتب محتوى تسويقي بارع.", template: "اكتب منشوراً اجتماعياً جذّاباً عن: {{input}}\nابدأ بخطّاف قوي، أضِف قيمة، ثم دعوة لإجراء و5 هاشتاقات مناسبة." } },
    { kind: "output", config: { template: "{{last}}" } } ] },
  { name: "باحث ويب (جلب + تلخيص)", nodes: [
    { kind: "input", config: {} },
    { kind: "fetch", config: { url: "{{input}}" } },
    { kind: "prompt", config: { system: "أنت ملخّص دقيق.", template: "لخّص محتوى الصفحة التالية بالعربية في نقاط واضحة:\n\n{{last}}" } },
    { kind: "output", config: { template: "{{last}}" } } ] },
  { name: "مترجم ومحسّن", nodes: [
    { kind: "input", config: {} },
    { kind: "prompt", config: { system: "مترجم محترف.", template: "ترجم النص التالي إلى العربية الفصحى ترجمة طبيعية ودقيقة:\n\n{{input}}" } },
    { kind: "prompt", config: { system: "محرّر لغوي.", template: "حسّن صياغة النص التالي واجعله أوضح وأكثر سلاسة، مع الحفاظ على المعنى:\n\n{{last}}" } },
    { kind: "output", config: { template: "{{last}}" } } ] },
  { name: "مولّد أفكار", nodes: [
    { kind: "input", config: {} },
    { kind: "prompt", config: { system: "خبير عصف ذهني مبدع.", template: "ولّد 10 أفكار إبداعية حول: {{input}}\nرتّبها من الأقوى للأضعف مع جملة تبرير لكل فكرة." } },
    { kind: "output", config: { template: "{{last}}" } } ] },
  { name: "محلّل وموجّه قرار", nodes: [
    { kind: "input", config: {} },
    { kind: "prompt", config: { system: "محلّل استراتيجي.", template: "حلّل الموقف التالي واذكر أبرز الإيجابيات والسلبيات:\n\n{{input}}" } },
    { kind: "prompt", config: { system: "مستشار عملي.", template: "بناءً على التحليل التالي، قدّم توصية واضحة بخطوات تنفيذية:\n\n{{last}}" } },
    { kind: "output", config: { template: "{{last}}" } } ] },
];

let flow = newFlow();
function newFlow() {
  return { id: uid(), name: "سلسلة جديدة", memory: "session",
    nodes: [{ id: uid(), kind: "input", config: {} }, { id: uid(), kind: "prompt", config: { template: "{{input}}" } }, { id: uid(), kind: "output", config: { template: "{{last}}" } }] };
}

export async function mount(container, intent) {
  container.innerHTML = `
  <div class="ph-head">
    <h3>توجيه الوكلاء</h3>
    <p class="muted small">ابنِ سلسلة مهام، اربط الخطوات بالمتغيرات {{input}} و{{last}} و{{step1}}، وشغّلها.</p>
  </div>

  <div class="card">
    <div class="row between">
      <input id="f-name" type="text" style="max-width:220px" placeholder="اسم السلسلة">
      <div class="row" style="gap:4px">
        <button class="btn sm" id="f-save">💾 حفظ</button>
        <button class="btn sm ghost" id="f-new">جديد</button>
      </div>
    </div>
    <div class="field" style="margin-top:10px">
      <label>المُدخل الابتدائي ({{input}})</label>
      <textarea id="f-input" rows="2" placeholder="النص الذي تبدأ به السلسلة..."></textarea>
    </div>
  </div>

  <div class="card">
    <h4 style="margin:0 0 8px">🧩 ابدأ بسرعة</h4>
    <div class="row wrap" style="gap:8px;align-items:end">
      <div class="field grow" style="margin:0"><label>نماذج وكلاء جاهزة</label>
        <select id="f-template">
          <option value="">— اختر نموذجاً —</option>
          ${AGENT_TEMPLATES.map((t, i) => `<option value="${i}">${esc(t.name)}</option>`).join("")}
        </select>
      </div>
      <button class="btn sm" id="f-load-tpl">تحميل النموذج</button>
    </div>
    <div class="field" style="margin-top:12px">
      <label>أو صِف الوكيل الذي تريده، وسيُنشئه الذكاء</label>
      <textarea id="f-describe" rows="2" placeholder="مثال: وكيل يبحث عن موضوع، يلخّص أهم النقاط، ثم يكتب تغريدة جذّابة"></textarea>
    </div>
    <button class="btn agent sm" id="f-ai-build">✨ أنشئ الوكيل بالذكاء</button>
  </div>

  <details class="builder" id="f-builder" style="margin-top:12px">
    <summary>🔧 تخصيص الخطوات (متقدّم)</summary>
    <div id="f-canvas" style="margin-top:10px"></div>
    <div class="add-row">
      <select id="f-addkind">${Object.entries(KIND).filter(([k]) => k !== "input").map(([k, v]) => `<option value="${k}">${v.icon} ${v.label}</option>`).join("")}</select>
      <button class="btn agent sm" id="f-add">+ إضافة خطوة</button>
    </div>
  </details>

  <div class="row" style="margin-top:12px">
    <button class="btn agent block" id="f-run">▶ تشغيل السلسلة <span class="pro-pill light">Pro</span></button>
  </div>
  <div id="f-log" style="margin-top:12px"></div>

  <div class="card" style="margin-top:14px">
    <h4>السلاسل المحفوظة</h4>
    <div id="f-saved" style="margin-top:8px"></div>
  </div>`;

  const nameEl = $("#f-name", container);
  const inputEl = $("#f-input", container);

  function syncHeader() { nameEl.value = flow.name; }
  syncHeader();
  nameEl.addEventListener("input", () => (flow.name = nameEl.value));

  function renderCanvas() {
    const cv = $("#f-canvas", container);
    cv.innerHTML = flow.nodes.map((n, i) => nodeCard(n, i)).join('<div class="flow-conn">↓</div>');
    flow.nodes.forEach((n) => wireNode(n, cv));
  }

  function nodeCard(n, i) {
    const k = KIND[n.kind];
    const movable = n.kind !== "input";
    return `<div class="node ${k.color}" data-id="${n.id}">
      <div class="row between">
        <span class="node-badge ${k.color}">${k.icon} ${k.label} <span class="muted small">#${i + 1}</span></span>
        <div class="row" style="gap:2px">
          ${movable ? `<button class="ic" data-act="up" title="أعلى">↑</button>
          <button class="ic" data-act="down" title="أسفل">↓</button>
          <button class="ic" data-act="del" title="حذف">✕</button>` : ""}
        </div>
      </div>
      ${nodeBody(n)}
    </div>`;
  }

  function nodeBody(n) {
    if (n.kind === "input") return `<div class="small muted">يأخذ النص من حقل «المُدخل الابتدائي» أعلاه.</div>`;
    if (n.kind === "prompt") return `
      <div class="field"><label>المزوّد</label>
        <select data-cfg="provider"><option value="">افتراضي (الإعدادات)</option>
          ${Object.entries(PROVIDERS).map(([k, v]) => `<option value="${k}" ${n.config.provider === k ? "selected" : ""}>${v.label}</option>`).join("")}
        </select></div>
      <div class="field"><label>تعليمات النظام (اختياري)</label><input type="text" data-cfg="system" value="${esc(n.config.system || "")}"></div>
      <div class="field"><label>البرومبت</label><textarea rows="3" data-cfg="template" class="code">${esc(n.config.template || "{{input}}")}</textarea></div>`;
    if (n.kind === "fetch") return `
      <div class="field"><label>الرابط (أو {{last}})</label><input type="text" data-cfg="url" value="${esc(n.config.url || "")}" placeholder="https://..."></div>
      <div class="small muted">سيُطلب إذنُ الوصول للنطاق عند أول تشغيل.</div>`;
    if (n.kind === "condition") return `
      <div class="field"><label>تابِع فقط إذا احتوى المخرَج السابق على:</label><input type="text" data-cfg="contains" value="${esc(n.config.contains || "")}"></div>`;
    if (n.kind === "output") return `
      <div class="field"><label>قالب المخرَج</label><textarea rows="2" data-cfg="template" class="code">${esc(n.config.template || "{{last}}")}</textarea></div>`;
    return "";
  }

  function wireNode(n, cv) {
    const card = cv.querySelector(`[data-id="${n.id}"]`);
    if (!card) return;
    $$("[data-cfg]", card).forEach((inp) => {
      inp.addEventListener("input", () => (n.config[inp.dataset.cfg] = inp.value));
      inp.addEventListener("change", () => (n.config[inp.dataset.cfg] = inp.value));
    });
    const idx = flow.nodes.indexOf(n);
    card.querySelector('[data-act="up"]')?.addEventListener("click", () => { if (idx > 0) { [flow.nodes[idx - 1], flow.nodes[idx]] = [flow.nodes[idx], flow.nodes[idx - 1]]; renderCanvas(); } });
    card.querySelector('[data-act="down"]')?.addEventListener("click", () => { if (idx < flow.nodes.length - 1) { [flow.nodes[idx + 1], flow.nodes[idx]] = [flow.nodes[idx], flow.nodes[idx + 1]]; renderCanvas(); } });
    card.querySelector('[data-act="del"]')?.addEventListener("click", () => { flow.nodes.splice(idx, 1); renderCanvas(); });
  }

  $("#f-add", container).onclick = () => {
    const kind = $("#f-addkind", container).value;
    const node = { id: uid(), kind, config: kind === "prompt" ? { template: "{{last}}" } : {} };
    const outIdx = flow.nodes.findIndex((x) => x.kind === "output");
    if (outIdx >= 0) flow.nodes.splice(outIdx, 0, node); else flow.nodes.push(node);
    renderCanvas();
  };

  $("#f-new", container).onclick = () => { flow = newFlow(); syncHeader(); inputEl.value = ""; $("#f-log", container).innerHTML = ""; renderCanvas(); };

  // تحميل نموذج وكيل جاهز
  $("#f-load-tpl", container).onclick = () => {
    const v = $("#f-template", container).value;
    if (v === "") return toast("اختر نموذجاً أولاً", "err");
    flow = cloneTemplate(AGENT_TEMPLATES[+v]); syncHeader(); $("#f-log", container).innerHTML = ""; renderCanvas();
    const b = $("#f-builder", container); if (b) b.open = true;
    toast("حُمّل النموذج — عدّله أو شغّله", "ok");
  };
  // إنشاء وكيل من وصف نصّي بالذكاء
  $("#f-ai-build", container).onclick = async (e) => {
    const desc = $("#f-describe", container).value.trim();
    if (!desc) return toast("اكتب وصف الوكيل أولاً", "err");
    if (!(await requirePro(FEATURE.AI_OPTIMIZE))) return;
    const s = await settings.get();
    if (!s.useServerProxy && !s.keys?.[s.defaultProvider]) return toast(`أضِف مفتاح ${PROVIDERS[s.defaultProvider].label} من الإعدادات، أو فعّل وكيل الخادم (Pro)`, "err");
    const btn = e.currentTarget; btn.disabled = true; btn.innerHTML = `<span class="spin"></span> جارٍ إنشاء الوكيل...`;
    try {
      flow = await aiBuildFlow(desc); syncHeader(); $("#f-log", container).innerHTML = ""; renderCanvas();
      const b = $("#f-builder", container); if (b) b.open = true;
      toast("أُنشئ الوكيل ✓ — راجع الخطوات ثم شغّله", "ok");
      container.scrollTo({ top: 0, behavior: "smooth" });
    } catch (err) { toast("تعذّر إنشاء الوكيل: " + (err.message || ""), "err"); }
    finally { btn.disabled = false; btn.innerHTML = "✨ أنشئ الوكيل بالذكاء"; }
  };

  $("#f-save", container).onclick = async () => {
    flow.updatedAt = now(); flow.createdAt = flow.createdAt || now();
    await db.put("flows", structuredClone(flow));
    toast("حُفظت السلسلة ✓", "ok"); renderSaved();
  };

  // التشغيل
  $("#f-run", container).onclick = async (e) => {
    const btn = e.currentTarget;
    if (!(await requirePro(FEATURE.AGENT_RUN))) return;
    const s = await settings.get();
    const needsModel = flow.nodes.some((n) => n.kind === "prompt");
    if (needsModel && !s.useServerProxy && !s.keys?.[s.defaultProvider]) return toast(`أضِف مفتاح ${PROVIDERS[s.defaultProvider].label} من الإعدادات، أو فعّل وكيل الخادم (Pro)`, "err");
    btn.disabled = true; btn.innerHTML = `<span class="spin"></span> جارٍ التشغيل...`;
    const logBox = $("#f-log", container);
    logBox.innerHTML = `<div class="card soft"><h4>سجل التنفيذ</h4><div id="log-items"></div></div>`;
    const items = $("#log-items", container);
    const ctx = { input: inputEl.value.trim(), steps: [], last: "" };
    try {
      for (let i = 0; i < flow.nodes.length; i++) {
        const n = flow.nodes[i]; const k = KIND[n.kind];
        const row = document.createElement("div"); row.className = "log-row";
        row.innerHTML = `<span class="node-badge ${k.color}">${k.icon} ${k.label} #${i + 1}</span> <span class="spin"></span>`;
        items.appendChild(row);
        let out = "", status = "ok", note = "";
        try {
          if (n.kind === "input") { out = ctx.input; }
          else if (n.kind === "output") { out = fillCtx(n.config.template || "{{last}}", ctx); }
          else if (n.kind === "condition") {
            const hay = ctx.last || ctx.steps[ctx.steps.length - 1] || "";
            const ok = hay.includes(n.config.contains || "");
            status = ok ? "ok" : "stop"; note = ok ? "تحقّق الشرط" : "لم يتحقّق — إيقاف"; out = hay;
            ctx.steps.push(out);
            row.innerHTML = logLine(k, i, status, note, out);
            if (!ok) break; else continue;
          }
          else if (n.kind === "fetch") {
            let url = fillCtx(n.config.url || "{{last}}", ctx).trim();
            out = await fetchText(url); note = url;
          }
          else if (n.kind === "prompt") {
            const user = fillCtx(n.config.template || "{{last}}", ctx);
            out = await callModel({ provider: n.config.provider || undefined, system: n.config.system, user, temperature: 0.5 });
          }
          ctx.steps.push(out); ctx.last = out || ctx.last;
          row.innerHTML = logLine(k, i, status, note, out);
        } catch (stepErr) {
          row.innerHTML = logLine(k, i, "err", stepErr.message || "خطأ", "");
          throw stepErr;
        }
      }
      toast("اكتمل التشغيل ✓", "ok");
    } catch (err) {
      toast("توقّف: " + (err.message || "خطأ"), "err");
    } finally { btn.disabled = false; btn.innerHTML = '▶ تشغيل السلسلة <span class="pro-pill light">Pro</span>'; }
  };

  async function renderSaved() {
    const all = (await db.all("flows")).sort((a, b) => (b.updatedAt || 0) - (a.updatedAt || 0));
    const box = $("#f-saved", container);
    if (!all.length) { box.innerHTML = `<div class="empty">لا سلاسل محفوظة بعد.</div>`; return; }
    box.innerHTML = all.map((f) => `
      <div class="lib-item" data-id="${f.id}">
        <div class="grow"><strong>${esc(f.name)}</strong>
          <div class="small muted">${f.nodes.length} خطوة</div></div>
        <div class="row" style="gap:4px">
          <button class="btn sm" data-act="load">تحميل</button>
          <button class="btn sm ghost" data-act="del">🗑</button>
        </div>
      </div>`).join("");
    $$(".lib-item", box).forEach((row) => {
      const id = row.dataset.id;
      row.querySelector('[data-act="load"]').onclick = async () => {
        const f = await db.get("flows", id); if (!f) return;
        flow = structuredClone(f); syncHeader(); renderCanvas();
        container.scrollTo({ top: 0, behavior: "smooth" }); toast("حُمّلت السلسلة", "ok");
      };
      row.querySelector('[data-act="del"]').onclick = async () => { await db.del("flows", id); renderSaved(); };
    });
  }

  renderCanvas(); renderSaved();
  if (intent?.text) { inputEl.value = intent.text; toast("تم استلام النص للمُدخل", "ok"); }
}

function fillCtx(tpl, ctx) {
  return String(tpl)
    .replace(/\{\{\s*input\s*\}\}/g, ctx.input || "")
    .replace(/\{\{\s*last\s*\}\}/g, ctx.last || "")
    .replace(/\{\{\s*step(\d+)\s*\}\}/g, (_, d) => ctx.steps[+d - 1] || "");
}

// نسخ نموذج جاهز إلى سلسلة جديدة بمعرّفات جديدة
function cloneTemplate(t) {
  return {
    id: uid(), name: t.name, memory: "session",
    nodes: t.nodes.map((n) => ({ id: uid(), kind: n.kind, config: { ...(n.config || {}) } })),
  };
}

// إنشاء سلسلة وكيل من وصف نصّي عبر النموذج (يعيد JSON ثم نطبّعه)
async function aiBuildFlow(desc) {
  const system = `أنت مصمّم سلاسل وكلاء لأداة Cognita. حوّل وصف المستخدم إلى سلسلة خطوات قابلة للتنفيذ.
أعِد JSON فقط دون أي شرح، بالشكل التالي:
{"name":"اسم مختصر للوكيل","nodes":[{"kind":"input","config":{}},{"kind":"prompt","config":{"system":"تعليمات النظام","template":"نص يستخدم {{input}} أو {{last}}"}},{"kind":"output","config":{"template":"{{last}}"}}]}
القواعد الصارمة:
- العقدة الأولى دائماً "input" والأخيرة دائماً "output".
- الأنواع المسموحة فقط: input, prompt, fetch (config.url), condition (config.contains), output.
- استخدم بين 2 و5 خطوات منطقية.
- اكتب تعليمات النظام والقوالب بالعربية، واستعمل {{input}} للمُدخل و{{last}} لناتج الخطوة السابقة.
- لا تُخرج أي نص خارج JSON.`;
  const out = await callModel({ system, user: desc, temperature: 0.4 });
  const match = String(out).match(/\{[\s\S]*\}/);
  if (!match) throw new Error("لم يُعِد النموذج صيغة صالحة");
  return normalizeFlow(JSON.parse(match[0]));
}

// تطبيع السلسلة المولّدة: ضمان input أولاً وoutput أخيراً وأنواع صحيحة
function normalizeFlow(j) {
  const allowed = ["input", "prompt", "fetch", "condition", "output"];
  let nodes = (Array.isArray(j?.nodes) ? j.nodes : []).filter((n) => n && allowed.includes(n.kind));
  const input = nodes.find((n) => n.kind === "input") || { kind: "input", config: {} };
  const output = nodes.find((n) => n.kind === "output") || { kind: "output", config: { template: "{{last}}" } };
  const mids = nodes.filter((n) => n.kind !== "input" && n.kind !== "output");
  if (!mids.length) mids.push({ kind: "prompt", config: { template: "{{input}}" } });
  const ordered = [input, ...mids, output];
  return {
    id: uid(), name: String(j?.name || "وكيل جديد").slice(0, 40), memory: "session",
    nodes: ordered.map((n) => ({ id: uid(), kind: n.kind, config: n.config && typeof n.config === "object" ? n.config : {} })),
  };
}

function logLine(k, i, status, note, out) {
  const dot = status === "ok" ? "ok" : status === "stop" ? "stop" : "err";
  const preview = out ? `<pre class="log-pre">${esc(String(out).slice(0, 600))}${String(out).length > 600 ? "…" : ""}</pre>` : "";
  return `<div class="row between"><span class="node-badge ${k.color}">${k.icon} ${k.label} #${i + 1}</span>
    <span class="status ${dot}">${status === "ok" ? "نجح" : status === "stop" ? "توقّف" : "خطأ"}</span></div>
    ${note ? `<div class="small muted" dir="auto">${esc(note)}</div>` : ""}${preview}`;
}

async function fetchText(url) {
  if (!/^https?:\/\//.test(url)) throw new Error("رابط غير صالح");
  const origin = new URL(url).origin + "/*";
  const granted = await chrome.permissions.request({ origins: [origin] }).catch(() => false);
  if (!granted) throw new Error("لم يُمنح إذن الوصول للنطاق");
  const res = await fetch(url);
  const html = await res.text();
  const text = html.replace(/<script[\s\S]*?<\/script>/gi, "").replace(/<style[\s\S]*?<\/style>/gi, "")
    .replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim();
  return text.slice(0, 4000);
}
