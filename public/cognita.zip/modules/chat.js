// modules/chat.js — المحادثة الذكية: تحدّث مع الصفحة الحالية + ذاكرة + إدخال/نطق صوتي
import { $, $$, esc, toast, copyText } from "../shared/util.js";
import { callModel, PROVIDERS } from "../shared/providers.js";
import { settings } from "../shared/store.js";
import { requirePro, FEATURE } from "../shared/license.js";

let messages = []; // يبقى عبر تبديل التبويبات ضمن جلسة اللوحة: {role:'user'|'assistant', content}

async function tabSend(type) {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id) return null;
    return await new Promise((res) => chrome.tabs.sendMessage(tab.id, { type }, (r) => res(chrome.runtime.lastError ? null : r)));
  } catch { return null; }
}

const STYLE = `
#cognita-chat .chat-log{display:flex;flex-direction:column;gap:10px;margin:12px 0;min-height:120px}
#cognita-chat .mr{max-width:92%}
#cognita-chat .mr.u{align-self:flex-start}
#cognita-chat .mr.a{align-self:flex-end}
#cognita-chat .bub{padding:10px 13px;border-radius:14px;font-size:13.5px;line-height:1.85;white-space:pre-wrap;word-break:break-word}
#cognita-chat .mr.u .bub{background:linear-gradient(135deg,var(--prompt,#6366f1),var(--agent,#a855f7));color:#fff;border-bottom-right-radius:4px}
#cognita-chat .mr.a .bub{background:var(--bg-soft,#1b2540);border:1px solid var(--line,#26304c);color:var(--ink,#eef2fb);border-bottom-left-radius:4px}
#cognita-chat .macts{margin-top:4px;display:flex;gap:6px}
#cognita-chat .macts button{background:none;border:0;color:var(--muted,#8a95b4);cursor:pointer;font-size:12px;padding:2px 4px}
#cognita-chat .macts button:hover{color:var(--ink,#eef2fb)}
#cognita-chat .chat-empty{text-align:center;color:var(--muted,#8a95b4);font-size:13px;padding:22px 8px}
#cognita-chat .chat-input{display:flex;gap:6px;align-items:flex-end;margin-top:8px}
#cognita-chat .chat-input textarea{flex:1;min-height:42px;max-height:120px}
#cognita-chat .mic.rec{background:var(--rose,#f43f5e);color:#fff}
`;

export async function mount(container, intent) {
  if (!document.getElementById("cognita-chat-style")) {
    const st = document.createElement("style"); st.id = "cognita-chat-style"; st.textContent = STYLE; document.head.appendChild(st);
  }
  container.innerHTML = `
  <div id="cognita-chat">
    <div class="ph-head">
      <h3>المحادثة الذكية</h3>
      <p class="muted small">اسأل أي شيء، أو تحدّث مع محتوى الصفحة الحالية — مع إدخال ونطق صوتي.</p>
    </div>
    <div class="card">
      <label class="chk" style="display:inline-flex;align-items:center;gap:7px"><input type="checkbox" id="c-usepage" checked> اعتمد على محتوى الصفحة الحالية</label>
      <div class="row wrap" style="gap:6px;margin-top:10px">
        <button class="btn sm" data-q="summary">📝 لخّص الصفحة</button>
        <button class="btn sm" data-q="points">• النقاط الرئيسية</button>
        <button class="btn sm" data-q="translate">🌍 ترجم المحدد</button>
        <button class="btn sm ghost" id="c-clear" style="margin-inline-start:auto">🗑 مسح</button>
      </div>
    </div>
    <div class="chat-log" id="chat-log"></div>
    <div class="chat-input">
      <textarea id="chat-text" rows="1" placeholder="اكتب رسالتك..."></textarea>
      <button class="btn ic mic" id="chat-mic" title="إدخال صوتي">🎙️</button>
      <button class="btn primary" id="chat-send">إرسال</button>
    </div>
  </div>`;

  const log = $("#chat-log", container);
  const input = $("#chat-text", container);

  function render() {
    if (!messages.length) { log.innerHTML = `<div class="chat-empty">ابدأ المحادثة 👋 — اسأل عن الصفحة أو أي موضوع.</div>`; return; }
    log.innerHTML = messages.map((m, i) => `
      <div class="mr ${m.role === "user" ? "u" : "a"}">
        <div class="bub">${m.role === "assistant" && m.content === "…" ? '<span class="spin"></span>' : esc(m.content)}</div>
        ${m.role === "assistant" && m.content !== "…" ? `<div class="macts">
          <button data-copy="${i}">نسخ</button><button data-speak="${i}">🔊 استماع</button></div>` : ""}
      </div>`).join("");
    log.scrollTop = log.scrollHeight;
    $$("[data-copy]", log).forEach((b) => b.onclick = () => copyText(messages[+b.dataset.copy].content));
    $$("[data-speak]", log).forEach((b) => b.onclick = () => speak(messages[+b.dataset.speak].content));
  }

  function speak(text) {
    try { speechSynthesis.cancel(); const u = new SpeechSynthesisUtterance(String(text)); u.lang = "ar-SA"; u.rate = 1; speechSynthesis.speak(u); }
    catch { toast("النطق الصوتي غير مدعوم", "err"); }
  }

  async function ask(text, { usePageOverride } = {}) {
    text = String(text || "").trim(); if (!text) return;
    if (!(await requirePro(FEATURE.AI_OPTIMIZE))) return;
    const s = await settings.get();
    if (!s.useServerProxy && !s.keys?.[s.defaultProvider]) return toast("اختر «مفتاحي الخاص» وأضِف مفتاحاً، أو فعّل خادم Cognita (Pro) من ⚙ الإعدادات", "err");
    messages.push({ role: "user", content: text }); input.value = ""; autosize();
    let pageCtx = "";
    const usePage = usePageOverride !== undefined ? usePageOverride : $("#c-usepage", container).checked;
    if (usePage) { const p = await tabSend("GET_PAGE_TEXT"); if (p?.text) pageCtx = `محتوى الصفحة الحالية («${p.title || ""}»):\n${p.text.slice(0, 8000)}\n\n---\n`; }
    const transcript = messages.slice(-10).map((m) => (m.role === "user" ? "المستخدم: " : "المساعد: ") + m.content).join("\n");
    const system = "أنت مساعد ذكي داخل متصفح المستخدم. أجب بالعربية بإيجاز ووضوح. إن وُجد «محتوى الصفحة» فاعتمد عليه أساساً للإجابة، وإن لم تجد الإجابة فيه فاذكر ذلك بوضوح.";
    const idx = messages.push({ role: "assistant", content: "…" }) - 1; render();
    try {
      const out = await callModel({ provider: s.defaultProvider, model: s.models?.[s.defaultProvider], system, user: pageCtx + transcript + "\nالمساعد:" });
      messages[idx].content = (out || "").trim() || "(لم يصل ردّ)";
    } catch (e) { messages[idx].content = "⚠️ " + (e.message || "تعذّر الحصول على ردّ"); }
    render();
  }

  function autosize() { input.style.height = "auto"; input.style.height = Math.min(input.scrollHeight, 120) + "px"; }
  input.addEventListener("input", autosize);
  input.addEventListener("keydown", (e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); ask(input.value); } });
  $("#chat-send", container).onclick = () => ask(input.value);
  $("#c-clear", container).onclick = () => { messages = []; render(); };

  // أزرار سريعة
  $$("[data-q]", container).forEach((b) => b.onclick = async () => {
    const q = b.dataset.q;
    if (q === "summary") ask("لخّص محتوى هذه الصفحة في فقرة موجزة ثم اذكر أهم النقاط.", { usePageOverride: true });
    else if (q === "points") ask("اذكر أهم النقاط الرئيسية في هذه الصفحة على شكل قائمة موجزة.", { usePageOverride: true });
    else if (q === "translate") {
      const sel = await tabSend("GET_SELECTION");
      if (!sel?.text) return toast("حدّد نصاً في الصفحة أولاً", "err");
      ask("ترجم النص التالي إلى العربية الفصحى ترجمة طبيعية:\n\n" + sel.text, { usePageOverride: false });
    }
  });

  // إدخال صوتي (Web Speech) — اختياري حسب دعم المتصفح
  const mic = $("#chat-mic", container);
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SR) { mic.disabled = true; mic.title = "الإدخال الصوتي غير مدعوم"; }
  else {
    let rec = null;
    mic.onclick = () => {
      if (rec) { rec.stop(); return; }
      try {
        rec = new SR(); rec.lang = "ar-SA"; rec.interimResults = false; rec.maxAlternatives = 1;
        mic.classList.add("rec");
        rec.onresult = (e) => { const t = e.results[0][0].transcript; input.value = (input.value ? input.value + " " : "") + t; autosize(); };
        rec.onerror = () => toast("تعذّر الإدخال الصوتي — تأكّد من إذن الميكروفون", "err");
        rec.onend = () => { mic.classList.remove("rec"); rec = null; };
        rec.start();
      } catch { mic.classList.remove("rec"); rec = null; toast("تعذّر بدء الإدخال الصوتي", "err"); }
    };
  }

  render();
  if (intent?.text) { input.value = intent.text; autosize(); }
}
