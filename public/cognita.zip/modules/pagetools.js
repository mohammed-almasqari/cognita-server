// modules/pagetools.js — أدوات الصفحة: مصحّح العربية RTL + تلخيص/ترجمة/شرح + مقتطفات + عدّاد
import { db, uid, now } from "../shared/db.js";
import { $, $$, esc, toast, copyText, estimateTokens, fmtTime } from "../shared/util.js";
import { callModel, PROVIDERS } from "../shared/providers.js";
import { requirePro, FEATURE } from "../shared/license.js";
import { settings } from "../shared/store.js";

async function tabMsg(type, payload = {}) {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id) throw new Error("لا يوجد تبويب نشط");
  return await new Promise((res, rej) => {
    chrome.tabs.sendMessage(tab.id, { type, ...payload }, (r) => {
      if (chrome.runtime.lastError) rej(new Error("افتح صفحة ويب عادية (لا تعمل على صفحات المتجر/الإعدادات)"));
      else res(r);
    });
  });
}

export async function mount(container) {
  container.innerHTML = `
  <div class="ph-head">
    <h3>أدوات الصفحة</h3>
    <p class="muted small">أدوات تعمل على الصفحة المفتوحة حالياً في متصفحك.</p>
  </div>

  <div class="card">
    <div class="row between">
      <div><h4 style="margin:0">🔄 مصحّح اتجاه العربية (RTL)</h4>
        <div class="muted small">يصلح المواقع التي تعرض العربية باتجاه خاطئ (من اليسار).</div></div>
      <button class="btn" id="rtl-toggle">…</button>
    </div>
    <div class="small muted" id="rtl-state" style="margin-top:8px"></div>
    <label class="chk" style="margin-top:10px"><input type="checkbox" id="rtl-global"> تفعيل تلقائي على كل المواقع</label>
  </div>

  <div class="card" style="margin-top:14px">
    <h4>أدوات بالذكاء</h4>
    <div class="row wrap" style="margin-top:8px">
      <button class="btn" id="pt-summary">📝 لخّص الصفحة</button>
      <button class="btn" id="pt-translate">🌍 ترجم التحديد</button>
      <button class="btn" id="pt-explain">💡 اشرح التحديد</button>
    </div>
    <div id="pt-out"></div>
  </div>

  <div class="card" style="margin-top:14px">
    <h4>أدوات إضافية</h4>
    <div class="row wrap" style="margin-top:8px">
      <button class="btn" id="pt-reader">📖 قارئ مركّز</button>
      <button class="btn" id="pt-contrast">♿ وضع الوصول/التباين</button>
      <button class="btn" id="pt-links">🔗 استخرج الروابط</button>
    </div>
    <div id="pt-links-out"></div>
  </div>

  <div class="card" style="margin-top:14px">
    <div class="row between">
      <h4 style="margin:0">✂️ مقتطفاتي</h4>
      <button class="btn sm" id="pt-clip">احفظ التحديد</button>
    </div>
    <div class="small muted" id="pt-count" style="margin-top:8px"></div>
    <div id="pt-clips" style="margin-top:10px"></div>
  </div>`;

  // ===== RTL =====
  const rtlBtn = $("#rtl-toggle", container);
  async function refreshRtl() {
    try {
      const s = await tabMsg("RTL_STATE");
      rtlBtn.textContent = s.on ? "إيقاف" : "تفعيل";
      rtlBtn.className = "btn " + (s.on ? "search" : "");
      $("#rtl-state", container).textContent = s.on ? `مفعّل على: ${s.host}` : "غير مفعّل على هذا الموقع";
    } catch (e) { rtlBtn.textContent = "تفعيل"; $("#rtl-state", container).textContent = e.message; }
  }
  rtlBtn.onclick = async () => {
    try { const r = await tabMsg("RTL_TOGGLE"); toast(r.on ? "تم التفعيل ✓" : "تم الإيقاف", "ok"); refreshRtl(); }
    catch (e) { toast(e.message, "err"); }
  };
  const gEl = $("#rtl-global", container);
  (await chrome.storage.local.get("rtlGlobal")).rtlGlobal && (gEl.checked = true);
  gEl.onchange = async () => {
    await chrome.storage.local.set({ rtlGlobal: gEl.checked });
    toast(gEl.checked ? "سيُفعّل على كل المواقع (بعد تحديثها)" : "أُلغي التفعيل العام", "ok");
  };
  refreshRtl();

  // ===== أدوات الذكاء =====
  function showOut(html) { $("#pt-out", container).innerHTML = `<div class="card soft fade" style="margin-top:12px">${html}</div>`; }
  async function aiTool(kind) {
    if (!(await requirePro(FEATURE.AI_OPTIMIZE))) return;
    const s = await settings.get();
    if (!s.useServerProxy && !PROVIDERS[s.defaultProvider]?.local && !s.keys?.[s.defaultProvider]) return toast(`أضِف مفتاح ${PROVIDERS[s.defaultProvider].label} من الإعدادات، أو اختر نموذجاً محلياً، أو فعّل وكيل الخادم (Pro)`, "err");
    let src, system, label;
    try {
      if (kind === "summary") {
        const p = await tabMsg("GET_PAGE_TEXT"); src = p.text;
        if (!src) return toast("لا يوجد نص في الصفحة", "err");
        system = "لخّص النص التالي بالعربية في نقاط واضحة موجزة، ثم اذكر «الخلاصة:» بسطر واحد."; label = "ملخّص الصفحة";
      } else {
        const sel = await tabMsg("GET_SELECTION");
        if (!sel.text) return toast("حدّد نصاً في الصفحة أولاً", "err");
        src = sel.text;
        if (kind === "translate") { system = "ترجم النص التالي إلى العربية الفصحى ترجمة دقيقة وطبيعية. أعِد الترجمة فقط."; label = "الترجمة"; }
        else { system = "اشرح النص التالي بالعربية ببساطة ووضوح مع مثال إن لزم."; label = "الشرح"; }
      }
    } catch (e) { return toast(e.message, "err"); }
    showOut(`<div class="diff-h">${label}</div><div class="row"><span class="spin"></span> جارٍ المعالجة...</div>`);
    try {
      const out = await callModel({ system, user: src.slice(0, 8000), temperature: 0.4 });
      showOut(`<div class="diff-h">${label}</div><pre style="white-space:pre-wrap">${esc(out)}</pre>
        <button class="btn sm" id="pt-copy">نسخ</button>`);
      $("#pt-copy", container).onclick = () => copyText(out);
    } catch (e) { showOut(`<div class="diff-h">${label}</div><div class="small" style="color:var(--rose)">${esc(e.message)}</div>`); }
  }
  $("#pt-summary", container).onclick = () => aiTool("summary");
  $("#pt-translate", container).onclick = () => aiTool("translate");
  $("#pt-explain", container).onclick = () => aiTool("explain");

  // ===== أدوات إضافية (مجانية) =====
  $("#pt-reader", container).onclick = async () => {
    try { const r = await tabMsg("READER_MODE"); toast(r.on ? "تم فتح القارئ المركّز ✓" : "أُغلق القارئ", "ok"); }
    catch (e) { toast(e.message, "err"); }
  };
  $("#pt-contrast", container).onclick = async () => {
    try { const r = await tabMsg("CONTRAST_MODE"); toast(r.on ? "تم تفعيل وضع التباين ✓" : "أُلغي وضع التباين", "ok"); }
    catch (e) { toast(e.message, "err"); }
  };
  $("#pt-links", container).onclick = async () => {
    try {
      const r = await tabMsg("EXTRACT_LINKS"); const ls = r.links || [];
      if (!ls.length) return toast("لا روابط في الصفحة", "err");
      $("#pt-links-out", container).innerHTML = `<div class="card soft" style="margin-top:10px">
        <div class="row between"><b>${ls.length} رابط</b><button class="btn sm" id="pt-links-copy">نسخ الكل</button></div>
        <div style="max-height:240px;overflow:auto;margin-top:8px">${ls.map((l) =>
          `<div class="small" style="padding:5px 0;border-bottom:1px solid var(--line)"><a href="${esc(l.href)}" target="_blank" rel="noopener noreferrer" dir="auto">${esc(l.text)}</a></div>`).join("")}</div></div>`;
      $("#pt-links-copy", container).onclick = () => copyText(ls.map((l) => l.href).join("\n"));
    } catch (e) { toast(e.message, "err"); }
  };

  // ===== عدّاد الصفحة =====
  try {
    const p = await tabMsg("GET_PAGE_TEXT");
    const words = (p.text.match(/\S+/g) || []).length;
    $("#pt-count", container).textContent = `الصفحة: ${words} كلمة · وقت قراءة ~${Math.max(1, Math.round(words / 220))} دقيقة`;
  } catch { $("#pt-count", container).textContent = ""; }

  // ===== المقتطفات =====
  $("#pt-clip", container).onclick = async () => {
    try {
      const sel = await tabMsg("GET_SELECTION");
      if (!sel.text) return toast("حدّد نصاً لحفظه", "err");
      await db.put("clippings", { id: uid(), text: sel.text, url: sel.url, title: sel.title, updatedAt: now() });
      toast("حُفظ المقتطف ✓", "ok"); renderClips();
    } catch (e) { toast(e.message, "err"); }
  };
  async function renderClips() {
    const all = (await db.all("clippings")).sort((a, b) => b.updatedAt - a.updatedAt);
    const box = $("#pt-clips", container);
    if (!all.length) { box.innerHTML = `<div class="empty">لا مقتطفات بعد.</div>`; return; }
    box.innerHTML = all.map((c) => `
      <div class="lib-item" data-id="${c.id}">
        <div class="grow"><div class="small">${esc(c.text.slice(0, 90))}${c.text.length > 90 ? "…" : ""}</div>
          <a class="small muted" href="${esc(c.url)}" target="_blank" rel="noopener noreferrer">${esc((c.title || c.url || "").slice(0, 40))}</a></div>
        <div class="row" style="gap:4px">
          <button class="btn sm ghost" data-act="copy">نسخ</button>
          <button class="btn sm ghost" data-act="del">🗑</button>
        </div>
      </div>`).join("");
    $$(".lib-item", box).forEach((row) => {
      const id = row.dataset.id;
      row.querySelector('[data-act="copy"]').onclick = async () => { const c = await db.get("clippings", id); copyText(c.text); };
      row.querySelector('[data-act="del"]').onclick = async () => { await db.del("clippings", id); renderClips(); };
    });
  }
  renderClips();
}
