// modules/search.js — وحدة البحث الذكي (تعمل بالكامل بلا اتصال؛ تحسين اختياري بالذكاء)
import { db, uid, now } from "../shared/db.js";
import { $, $$, esc, toast, copyText } from "../shared/util.js";
import { callModel, PROVIDERS } from "../shared/providers.js";
import { settings } from "../shared/store.js";
import { requirePro, can, limit, FEATURE } from "../shared/license.js";

const ENGINES = {
  google: { label: "Google", url: (q) => "https://www.google.com/search?q=" + encodeURIComponent(q), ops: true },
  bing: { label: "Bing", url: (q) => "https://www.bing.com/search?q=" + encodeURIComponent(q), ops: true },
  scholar: { label: "Scholar", url: (q) => "https://scholar.google.com/scholar?q=" + encodeURIComponent(q), ops: true },
  perplexity: { label: "Perplexity", url: (q) => "https://www.perplexity.ai/search?q=" + encodeURIComponent(q), ops: false },
};
const FILETYPES = ["", "pdf", "doc", "docx", "ppt", "pptx", "xls", "csv"];

export async function mount(container, intent) {
  container.innerHTML = `
  <div class="ph-head">
    <h3>البحث الذكي</h3>
    <p class="muted small">حوّل فكرتك إلى استعلامات احترافية لكل محرك، وقارنها جنباً إلى جنب.</p>
  </div>

  <div class="card">
    <div class="field">
      <label>الفكرة الخام</label>
      <textarea id="s-idea" rows="3" placeholder="مثال: دراسات حديثة عن أثر الذكاء الاصطناعي على التعليم الجامعي بصيغة PDF من مصادر أكاديمية"></textarea>
    </div>

    <details class="builder" open>
      <summary>⚙ العوامل المتقدمة</summary>
      <div class="row">
        <div class="field grow"><label>النطاق site:</label><input id="o-site" type="text" placeholder="nature.com"></div>
        <div class="field"><label>نوع الملف</label><select id="o-filetype">${FILETYPES.map((f) => `<option value="${f}">${f || "—"}</option>`).join("")}</select></div>
      </div>
      <div class="row">
        <div class="field grow"><label>عبارة حرفية "…"</label><input id="o-exact" type="text" placeholder="machine learning"></div>
        <div class="field grow"><label>في العنوان intitle:</label><input id="o-intitle" type="text"></div>
      </div>
      <div class="row">
        <div class="field grow"><label>استبعاد (مفصولة بمسافة) −</label><input id="o-exclude" type="text" placeholder="إعلان تسويق"></div>
        <div class="field grow"><label>بدائل OR</label><input id="o-or" type="text" placeholder="solar wind"></div>
      </div>
      <div class="field"><label>بعد سنة (after:)</label><input id="o-after" type="number" placeholder="2023" min="1990" max="2030"></div>
    </details>

    <div class="field">
      <label>المحركات</label>
      <div class="row wrap" id="s-engines">
        ${Object.entries(ENGINES).map(([k, e], i) => `<label class="chk"><input type="checkbox" value="${k}" ${i < 3 ? "checked" : ""}> ${e.label}</label>`).join("")}
      </div>
    </div>

    <div class="row wrap">
      <button class="btn search" id="s-gen">⚡ ولّد الاستعلامات</button>
      <button class="btn" id="s-auto">🚀 ابحث نيابة عني <span class="pro-pill">Pro</span></button>
      <button class="btn" id="s-ai">🤖 حسّن + مرادفات</button>
      <button class="btn" id="s-save">💾 حفظ الملف</button>
    </div>
    <div id="s-syn"></div>
  </div>

  <div id="s-results" style="margin-top:14px"></div>

  <div class="card" style="margin-top:14px">
    <h4>الملفات المحفوظة</h4>
    <div id="s-saved" style="margin-top:8px"></div>
  </div>`;

  const getOps = () => ({
    site: $("#o-site", container).value.trim(),
    filetype: $("#o-filetype", container).value,
    exact: $("#o-exact", container).value.trim(),
    intitle: $("#o-intitle", container).value.trim(),
    exclude: $("#o-exclude", container).value.trim(),
    or: $("#o-or", container).value.trim(),
    after: $("#o-after", container).value.trim(),
  });
  const getEngines = () => $$('#s-engines input:checked', container).map((c) => c.value);

  function buildQuery(idea, ops, engine) {
    const terms = cleanIdea(idea);
    if (engine === "perplexity") {
      // محرك حواري: سؤال طبيعي بلا عوامل
      let q = idea.trim();
      if (ops.after) q += ` (منذ ${ops.after})`;
      if (ops.site) q += ` من ${ops.site}`;
      return q;
    }
    const parts = [terms];
    if (ops.exact) parts.push(`"${ops.exact}"`);
    if (ops.or) parts.push("(" + ops.or.split(/\s+/).join(" OR ") + ")");
    if (ops.intitle) parts.push(`intitle:${ops.intitle}`);
    if (ops.site) parts.push(`site:${ops.site}`);
    if (ops.filetype) parts.push(`filetype:${ops.filetype}`);
    if (ops.exclude) ops.exclude.split(/\s+/).forEach((w) => parts.push(`-${w}`));
    if (ops.after) parts.push(`after:${ops.after}-01-01`);
    return parts.filter(Boolean).join(" ");
  }

  let lastQueries = [];
  function generate() {
    const idea = $("#s-idea", container).value.trim();
    if (!idea) return toast("اكتب الفكرة أولاً", "err");
    const ops = getOps();
    const engines = getEngines();
    if (!engines.length) return toast("اختر محركاً واحداً على الأقل", "err");
    lastQueries = engines.map((k) => ({ engine: k, query: buildQuery(idea, ops, k) }));
    renderResults();
    renderSynonyms(localSynonyms(idea));
  }

  function renderResults() {
    const box = $("#s-results", container);
    if (!lastQueries.length) { box.innerHTML = ""; return; }
    box.innerHTML = `<div class="row between"><h4 style="margin:0">وضع المقارنة</h4>
      <button class="btn sm" id="s-openall">فتح الكل</button></div>` +
      lastQueries.map((q, i) => `
      <div class="card soft res" style="margin-top:10px">
        <div class="row between">
          <span class="pill s">${ENGINES[q.engine].label}</span>
          <div class="row" style="gap:4px">
            <button class="btn sm" data-i="${i}" data-act="open">فتح ↗</button>
            <button class="btn sm ghost" data-i="${i}" data-act="copy">نسخ</button>
          </div>
        </div>
        <pre class="qpre" dir="auto">${esc(q.query)}</pre>
      </div>`).join("");
    $("#s-openall", container).onclick = () => lastQueries.forEach((q) => openQ(q));
    $$('[data-act="open"]', box).forEach((b) => (b.onclick = () => openQ(lastQueries[+b.dataset.i])));
    $$('[data-act="copy"]', box).forEach((b) => (b.onclick = () => copyText(lastQueries[+b.dataset.i].query)));
  }
  const openQ = (q) => chrome.tabs.create({ url: ENGINES[q.engine].url(q.query) });

  function renderSynonyms(words) {
    const box = $("#s-syn", container);
    if (!words.length) { box.innerHTML = ""; return; }
    box.innerHTML = `<div class="small muted" style="margin-top:10px">كلمات مقترحة (انقر للإضافة للعبارة الحرفية):</div>
      <div class="row wrap" style="margin-top:4px">${words.map((w) => `<button class="tag syn">${esc(w)}</button>`).join("")}</div>`;
    $$(".syn", box).forEach((b) => (b.onclick = () => {
      const f = $("#o-exact", container); f.value = (f.value ? f.value + " " : "") + b.textContent; toast("أُضيفت", "ok");
    }));
  }

  $("#s-gen", container).onclick = generate;

  // بحث تلقائي «نيابة عن المستخدم»: يفتح التبويبات ويجمّعها
  $("#s-auto", container).onclick = async () => {
    const idea = $("#s-idea", container).value.trim();
    if (!idea) return toast("اكتب الفكرة أولاً", "err");
    if (!lastQueries.length) generate();
    if (!lastQueries.length) return;
    const multi = await can(FEATURE.AUTO_SEARCH_MULTI);
    const maxTabs = multi ? (await limit("autoSearchTabs")) || 8 : 1;
    const chosen = lastQueries.slice(0, maxTabs);
    const tabIds = [];
    for (const q of chosen) {
      try {
        const tab = await chrome.tabs.create({ url: ENGINES[q.engine].url(q.query), active: false });
        if (tab?.id) tabIds.push(tab.id);
      } catch (e) { /* تجاهل تبويب فاشل */ }
    }
    // تجميع التبويبات في مجموعة واحدة باسم الفكرة
    try {
      if (chrome.tabs.group && tabIds.length > 1) {
        const groupId = await chrome.tabs.group({ tabIds });
        if (chrome.tabGroups?.update)
          await chrome.tabGroups.update(groupId, { title: "Cognita: " + idea.slice(0, 22), color: "purple" });
      }
    } catch (e) { /* تجميع اختياري */ }
    if (!multi && lastQueries.length > 1)
      toast(`فُتح محرك واحد (الخطة المجانية). فعّل Pro لفتح ${lastQueries.length} محركات معاً`, "err");
    else if (tabIds.length)
      toast(`تم فتح ${tabIds.length} تبويب نيابةً عنك ✓`, "ok");
    else
      toast("تعذّر فتح التبويبات", "err");
  };

  // تحسين بالذكاء: مرادفات + إعادة صياغة الفكرة
  $("#s-ai", container).onclick = async (e) => {
    const idea = $("#s-idea", container).value.trim();
    if (!idea) return toast("اكتب الفكرة أولاً", "err");
    if (!(await requirePro(FEATURE.AI_OPTIMIZE))) return;
    const s = await settings.get();
    if (!s.useServerProxy && !PROVIDERS[s.defaultProvider]?.local && !s.keys?.[s.defaultProvider]) return toast(`أضِف مفتاح ${PROVIDERS[s.defaultProvider].label} من الإعدادات، أو اختر نموذجاً محلياً، أو فعّل وكيل الخادم (Pro)`, "err");
    const btn = e.currentTarget; btn.disabled = true; btn.innerHTML = `<span class="spin"></span> جارٍ...`;
    try {
      const system = "أنت خبير في استرجاع المعلومات. من فكرة المستخدم استخرج: (1) صياغة بحثية إنجليزية مختصرة دقيقة، (2) قائمة 6 كلمات/مرادفات مفصولة بفواصل. أعِد JSON فقط بالشكل {\"query\":\"...\",\"keywords\":[\"...\"]}";
      const out = await callModel({ system, user: idea, temperature: 0.3 });
      const json = JSON.parse(out.match(/\{[\s\S]*\}/)[0]);
      if (json.query) $("#o-exact", container).value = json.query;
      renderSynonyms(json.keywords || []);
      toast("تم التحسين ✓ — اضغط «ولّد»", "ok");
    } catch (err) { toast("تعذّر التحسين: " + (err.message || ""), "err"); }
    finally { btn.disabled = false; btn.innerHTML = "🤖 حسّن + مرادفات"; }
  };

  $("#s-save", container).onclick = async () => {
    const idea = $("#s-idea", container).value.trim();
    if (!idea) return toast("لا شيء للحفظ", "err");
    await db.put("searches", {
      id: uid(), rawIdea: idea, engines: getEngines(), queries: lastQueries,
      ops: getOps(), createdAt: now(), updatedAt: now(),
    });
    toast("حُفظ ✓", "ok"); renderSaved();
  };

  async function renderSaved() {
    const all = (await db.all("searches")).sort((a, b) => b.updatedAt - a.updatedAt);
    const box = $("#s-saved", container);
    if (!all.length) { box.innerHTML = `<div class="empty">لا ملفات محفوظة بعد.</div>`; return; }
    box.innerHTML = all.map((p) => `
      <div class="lib-item" data-id="${p.id}">
        <div class="grow"><strong>${esc(p.rawIdea.slice(0, 50))}${p.rawIdea.length > 50 ? "…" : ""}</strong>
          <div class="small muted">${(p.engines || []).join("، ")}</div></div>
        <div class="row" style="gap:4px">
          <button class="btn sm" data-act="load">تحميل</button>
          <button class="btn sm ghost" data-act="del">🗑</button>
        </div>
      </div>`).join("");
    $$(".lib-item", box).forEach((row) => {
      const id = row.dataset.id;
      row.querySelector('[data-act="load"]').onclick = async () => {
        const p = await db.get("searches", id);
        $("#s-idea", container).value = p.rawIdea;
        lastQueries = p.queries || []; renderResults();
        container.scrollTo({ top: 0, behavior: "smooth" });
      };
      row.querySelector('[data-act="del"]').onclick = async () => { await db.del("searches", id); renderSaved(); };
    });
  }
  renderSaved();

  if (intent?.text) { $("#s-idea", container).value = intent.text; generate(); }
}

function cleanIdea(idea) {
  const fillers = ["أبحث عن", "ابحث عن", "أريد", "اريد", "من فضلك", "حول", "عن", "دراسات", "معلومات"];
  let t = idea;
  fillers.forEach((f) => (t = t.replace(new RegExp(f, "g"), " ")));
  return t.replace(/\s+/g, " ").trim();
}
function localSynonyms(idea) {
  const words = (idea.match(/[\p{L}]{4,}/gu) || []).slice(0, 6);
  return [...new Set(words)];
}
