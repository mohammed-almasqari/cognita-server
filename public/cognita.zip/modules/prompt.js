// modules/prompt.js — وحدة هندسة البرومبت
import { db, uid, now } from "../shared/db.js";
import { $, $$, esc, extractVars, fillVars, estimateTokens, toast, copyText } from "../shared/util.js";
import { MODEL_STYLES } from "../shared/templates.js";
import { callModel, PROVIDERS } from "../shared/providers.js";
import { settings } from "../shared/store.js";
import { requirePro, FEATURE } from "../shared/license.js";

let current = null; // البرومبت المحرَّر حالياً

export async function mount(container, intent) {
  container.innerHTML = `
  <div class="ph-head">
    <h3>هندسة البرومبت</h3>
    <p class="muted small">اكتب برومبت، اختر المزوّد والنموذج، ثم حسّنه بالذكاء.</p>
  </div>

  <div class="card">
    <div class="field">
      <label>العنوان</label>
      <input id="p-title" type="text" placeholder="مثال: كاتب محتوى تسويقي">
    </div>
    <div class="row">
      <div class="field grow">
        <label>المزوّد</label>
        <select id="p-provider">${Object.entries(PROVIDERS).map(([k, p]) => `<option value="${k}">${p.label}</option>`).join("")}</select>
      </div>
      <div class="field grow">
        <label>النموذج</label>
        <select id="p-model"></select>
      </div>
    </div>
    <div class="model-tip muted small" id="p-tip"></div>
    <div class="muted small" id="p-proxy-hint" style="display:none;background:var(--bg-soft,#f1f3f9);border-radius:8px;padding:7px 10px;margin-top:4px">🛡️ وضع وكيل الخادم مُفعّل — يحدّد الخادم المزوّد والنموذج تلقائياً.</div>

    <div class="field">
      <label>نص البرومبت <span class="muted">— استخدم {{المتغيّر}} للحقول الديناميكية</span></label>
      <textarea id="p-body" class="code" rows="9" placeholder="اكتب البرومبت هنا..."></textarea>
      <div class="row between small muted" style="margin-top:6px">
        <span id="p-stats">٠ حرف · ~٠ رمز</span>
        <span id="p-varcount"></span>
      </div>
    </div>

    <details class="builder">
      <summary>⚙ مولّد قالب سريع (دور/مهمة/قيود/صيغة)</summary>
      <div class="field"><label>الدور</label><input id="b-role" type="text" placeholder="مساعد خبير في ..."></div>
      <div class="field"><label>المهمة</label><textarea id="b-task" rows="2" placeholder="صف المهمة..."></textarea></div>
      <div class="row">
        <div class="field grow"><label>القيود</label><input id="b-constraints" type="text"></div>
        <div class="field grow"><label>صيغة المخرَج</label><input id="b-format" type="text"></div>
      </div>
      <button class="btn primary sm" id="b-gen">ولّد القالب حسب النموذج</button>
    </details>

    <div id="p-vars" class="vars-box"></div>

    <div class="row wrap" style="margin-top:12px;gap:8px">
      <button class="btn primary" id="p-ai">🤖 تحسين بالذكاء <span class="pro-pill">Pro</span></button>
      <button class="btn" id="p-copy">📋 نسخ</button>
      <button class="btn" id="p-save">💾 حفظ</button>
    </div>
    <div class="row wrap" style="margin-top:6px;gap:8px">
      <button class="btn ghost sm" id="p-rule">✨ تحسين بالقواعد</button>
      <button class="btn ghost sm" id="p-insert">إدراج بالصفحة</button>
      <button class="btn ghost sm" id="p-new">جديد</button>
    </div>
    <div id="p-opt-note"></div>
  </div>

  <div class="card" style="margin-top:14px">
    <div class="row between">
      <h4 style="margin:0">المكتبة</h4>
      <input id="p-search" type="text" placeholder="بحث..." style="max-width:160px">
    </div>
    <div id="p-list" style="margin-top:10px"></div>
  </div>`;

  const body = $("#p-body", container);
  const titleEl = $("#p-title", container);
  const provEl = $("#p-provider", container);
  const modelEl = $("#p-model", container);

  const styleFor = (prov) => MODEL_STYLES[prov] || MODEL_STYLES.openai;
  function fillModels(prov, sel) {
    const models = PROVIDERS[prov]?.models || [];
    modelEl.innerHTML = models.map((m) => `<option value="${m}">${m}</option>`).join("");
    if (sel && models.includes(sel)) modelEl.value = sel;
  }
  async function persistModel() { await settings.set({ defaultProvider: provEl.value, models: { [provEl.value]: modelEl.value } }); }
  // تهيئة المزوّد/النموذج من الإعدادات (مصدر الحقيقة الموحّد)
  const s0 = await settings.get();
  provEl.value = PROVIDERS[s0.defaultProvider] ? s0.defaultProvider : "openai";
  fillModels(provEl.value, s0.models?.[provEl.value]);
  $("#p-proxy-hint", container).style.display = s0.useServerProxy ? "block" : "none";

  const refreshTip = () => { const st = styleFor(provEl.value); $("#p-tip", container).textContent = st?.tip ? "💡 " + st.tip : ""; };
  const refreshStats = () => {
    const t = body.value;
    $("#p-stats", container).textContent = `${t.length} حرف · ~${estimateTokens(t)} رمز`;
    renderVars();
  };
  function renderVars() {
    const vars = extractVars(body.value);
    $("#p-varcount", container).textContent = vars.length ? `${vars.length} متغيّر` : "";
    const box = $("#p-vars", container);
    if (!vars.length) { box.innerHTML = ""; return; }
    box.innerHTML = `<div class="vars-title small muted">املأ المتغيّرات:</div>` +
      vars.map((v) => `<div class="field"><label>${esc(v.key)}</label><input data-var="${esc(v.key)}" type="text" placeholder="${esc(v.key)}"></div>`).join("") +
      `<button class="btn sm" id="p-preview">معاينة بعد التعويض</button>`;
    $("#p-preview", container).onclick = () => {
      const values = {};
      $$("[data-var]", box).forEach((i) => (values[i.dataset.var] = i.value));
      const filled = fillVars(body.value, values);
      showNote(`<div class="diff"><div class="diff-h">النتيجة بعد التعويض</div><pre>${esc(filled)}</pre>
        <button class="btn sm" id="pv-copy">نسخ النتيجة</button></div>`);
      $("#pv-copy", container).onclick = () => copyText(filled);
    };
  }
  function getFilledBody() {
    const values = {};
    $$("#p-vars [data-var]", container).forEach((i) => { if (i.value) values[i.dataset.var] = i.value; });
    return fillVars(body.value, values);
  }
  function showNote(html) { $("#p-opt-note", container).innerHTML = `<div class="card soft fade" style="margin-top:12px">${html}</div>`; }

  body.addEventListener("input", refreshStats);
  provEl.addEventListener("change", () => { fillModels(provEl.value); refreshTip(); persistModel(); });
  modelEl.addEventListener("change", persistModel);
  refreshTip(); refreshStats();

  // مولّد القالب
  $("#b-gen", container).onclick = () => {
    const p = {
      role: $("#b-role", container).value, task: $("#b-task", container).value,
      constraints: $("#b-constraints", container).value, format: $("#b-format", container).value,
      context: $("#b-task", container).value,
    };
    if (!p.task) return toast("اكتب المهمة أولاً", "err");
    body.value = styleFor(provEl.value).wrap(p);
    refreshStats();
    toast("تم توليد القالب ✓", "ok");
  };

  // تحسين بالقواعد (بلا اتصال)
  $("#p-rule", container).onclick = () => {
    const { text, notes } = ruleOptimize(body.value, provEl.value);
    body.value = text; refreshStats();
    showNote(`<div class="diff-h">✨ تحسين بالقواعد</div><ul class="small">${notes.map((n) => `<li>${esc(n)}</li>`).join("")}</ul>`);
  };

  // تحسين بالذكاء (يحتاج مفتاح)
  $("#p-ai", container).onclick = async (e) => {
    const btn = e.currentTarget;
    if (!body.value.trim()) return toast("اكتب برومبت أولاً", "err");
    if (!(await requirePro(FEATURE.AI_OPTIMIZE))) return;
    const s = await settings.get();
    const prov = provEl.value;
    if (!s.useServerProxy && !s.keys?.[prov]) return toast(`أضِف مفتاح ${PROVIDERS[prov].label} من الإعدادات، أو فعّل وكيل الخادم (Pro)`, "err");
    const orig = body.value;
    btn.disabled = true; btn.innerHTML = `<span class="spin"></span> جارٍ التحسين...`;
    try {
      const system = `أنت خبير في هندسة البرومبت. أعد كتابة برومبت المستخدم ليكون أوضح وأكثر فعالية مع نموذج «${styleFor(prov).name}». حافظ على متغيرات {{...}} كما هي. أعِد البرومبت المحسّن فقط دون شرح.`;
      const out = await callModel({ provider: prov, model: modelEl.value, system, user: orig, temperature: 0.4 });
      body.value = out; refreshStats();
      showNote(`<div class="diff-h">🤖 محسّن عبر ${PROVIDERS[prov].label}</div>
        <details class="small"><summary>عرض النص الأصلي</summary><pre>${esc(orig)}</pre></details>`);
      toast("تم التحسين ✓", "ok");
    } catch (err) {
      toast(err.message || "فشل التحسين", "err");
    } finally { btn.disabled = false; btn.innerHTML = '🤖 تحسين بالذكاء <span class="pro-pill">Pro</span>'; }
  };

  $("#p-copy", container).onclick = () => copyText(getFilledBody());
  $("#p-insert", container).onclick = async () => {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id) return toast("لا يوجد تبويب نشط", "err");
    chrome.tabs.sendMessage(tab.id, { type: "INSERT_TEXT", text: getFilledBody() }, (res) => {
      if (chrome.runtime.lastError || !res?.ok) toast("تعذّر الإدراج — جرّب صفحة نموذج مدعومة", "err");
      else toast("تم الإدراج ✓", "ok");
    });
  };

  $("#p-save", container).onclick = async () => {
    if (!body.value.trim()) return toast("لا يوجد محتوى للحفظ", "err");
    const rec = {
      id: current?.id || uid(),
      title: titleEl.value.trim() || "بدون عنوان",
      targetModel: provEl.value,
      body: body.value,
      variables: extractVars(body.value),
      tags: current?.tags || [],
      favorite: current?.favorite || false,
      createdAt: current?.createdAt || now(),
      updatedAt: now(),
      version: (current?.version || 0) + 1,
    };
    await db.put("prompts", rec); current = rec;
    toast("حُفظ في المكتبة ✓", "ok"); renderList();
  };

  $("#p-new", container).onclick = () => {
    current = null; titleEl.value = ""; body.value = ""; refreshStats();
    $("#p-opt-note", container).innerHTML = "";
  };

  // المكتبة
  const searchEl = $("#p-search", container);
  searchEl.addEventListener("input", renderList);
  async function renderList() {
    const all = (await db.all("prompts")).sort((a, b) => b.updatedAt - a.updatedAt);
    const q = searchEl.value.trim().toLowerCase();
    const items = all.filter((p) => !q || (p.title + p.body + (p.tags || []).join(",")).toLowerCase().includes(q));
    const list = $("#p-list", container);
    if (!items.length) { list.innerHTML = `<div class="empty">لا توجد عناصر${q ? " مطابقة" : " بعد"}.</div>`; return; }
    list.innerHTML = items.map((p) => `
      <div class="lib-item" data-id="${p.id}">
        <div class="grow">
          <div class="row" style="gap:6px">
            <strong>${esc(p.title)}</strong>
            <span class="pill p">${(MODEL_STYLES[p.targetModel]?.name) || (PROVIDERS[p.targetModel]?.label) || p.targetModel}</span>
            ${p.favorite ? '<span title="مفضّل">★</span>' : ""}
          </div>
          <div class="small muted">${esc(p.body.slice(0, 80))}${p.body.length > 80 ? "…" : ""}</div>
        </div>
        <div class="row" style="gap:4px">
          <button class="btn sm" data-act="load">فتح</button>
          <button class="btn sm ghost" data-act="fav">${p.favorite ? "★" : "☆"}</button>
          <button class="btn sm ghost" data-act="del">🗑</button>
        </div>
      </div>`).join("");
    $$(".lib-item", list).forEach((row) => {
      const id = row.dataset.id;
      row.querySelector('[data-act="load"]').onclick = async () => {
        const p = await db.get("prompts", id); if (!p) return;
        current = p; titleEl.value = p.title; body.value = p.body;
        if (PROVIDERS[p.targetModel]) { provEl.value = p.targetModel; fillModels(provEl.value, s0.models?.[provEl.value]); }
        refreshTip(); refreshStats(); container.scrollTo({ top: 0, behavior: "smooth" });
        toast("تم الفتح", "ok");
      };
      row.querySelector('[data-act="fav"]').onclick = async () => {
        const p = await db.get("prompts", id); p.favorite = !p.favorite; await db.put("prompts", p); renderList();
      };
      row.querySelector('[data-act="del"]').onclick = async () => {
        await db.del("prompts", id); if (current?.id === id) current = null; toast("حُذف", "ok"); renderList();
      };
    });
  }
  renderList();

  // نية واردة من قائمة السياق / الزر العائم
  if (intent?.text) {
    body.value = intent.text; refreshStats();
    titleEl.value = "من التحديد";
    toast("تم استلام النص المحدّد", "ok");
  }
}

// محرّك التحسين بالقواعد (بلا نموذج)
function ruleOptimize(text, model) {
  const notes = [];
  let t = text.replace(/[ \t]+\n/g, "\n").replace(/\n{3,}/g, "\n\n").trim();
  if (t !== text.trim()) notes.push("تنظيف المسافات والأسطر الزائدة.");

  const hasRole = /دور|role|أنت|تصرّف/i.test(t);
  const hasFormat = /صيغة|format|بصيغة|أخرِج/i.test(t);

  if (!hasRole) {
    t = `# الدور\nأنت مساعد خبير ومتخصص.\n\n# المهمة\n${t}`;
    notes.push("إضافة قسم «الدور» لتوجيه النموذج.");
  }
  if (!hasFormat) {
    t += `\n\n# صيغة المخرَج\nقدّم الإجابة منظّمة وواضحة، مع عناوين عند الحاجة.`;
    notes.push("إضافة تحديد صريح لصيغة المخرَج.");
  }
  // تحويل أسطر تبدأ بـ - إلى صياغة موحّدة
  notes.push(`موائمة البنية لأسلوب ${(MODEL_STYLES[model] || MODEL_STYLES.openai).name}.`);
  if (!notes.length) notes.push("البرومبت جيّد بالفعل — لا تغييرات جوهرية.");
  return { text: t, notes };
}
