// shared/api.js — عميل الطبقة الخلفية (قابل للضبط عبر الإعدادات)
import { settings } from "./store.js";
import { safeFetch, AppError } from "./net.js";

async function base() {
  const s = await settings.get();
  const url = (s.backendUrl || "").replace(/\/+$/, "");
  if (!url) throw new AppError("لم يُضبط رابط الخادم. أضِفه من الإعدادات ← الحساب.", "bad");
  return url;
}
async function token() {
  const s = await settings.get();
  return s.auth?.token || "";
}
function authHeaders(t) {
  return t ? { Authorization: `Bearer ${t}` } : {};
}

// طلب إذن الوصول لنطاق الخادم (host permission ديناميكي)
export async function ensureHostPermission(url) {
  try {
    const origin = new URL(url).origin + "/*";
    const has = await chrome.permissions.contains({ origins: [origin] });
    if (has) return true;
    return await chrome.permissions.request({ origins: [origin] });
  } catch { return false; }
}

async function jpost(path, body, withAuth = true) {
  const b = await base();
  const t = withAuth ? await token() : "";
  const res = await safeFetch(b + path, {
    method: "POST",
    headers: { "Content-Type": "application/json", ...authHeaders(t) },
    body: JSON.stringify(body || {}),
  });
  return res.json();
}
async function jget(path) {
  const b = await base();
  const t = await token();
  const res = await safeFetch(b + path, { headers: authHeaders(t) });
  return res.json();
}

export const api = {
  async register(email, password) {
    const data = await jpost("/api/auth/register", { email, password }, false);
    await settings.set({ auth: { token: data.token, email: data.user?.email } });
    return data;
  },
  async login(email, password) {
    const data = await jpost("/api/auth/login", { email, password }, false);
    await settings.set({ auth: { token: data.token, email: data.user?.email } });
    return data;
  },
  async logout() { await settings.set({ auth: { token: "", email: "" } }); },
  me() { return jget("/api/me"); },
  activate(key) { return jpost("/api/license/activate", { key }); },
  validate() { return jget("/api/license/validate"); },
  syncPush(payload) { return jpost("/api/sync/push", payload); },
  syncPull() { return jget("/api/sync/pull"); },
  // وكيل النماذج المركزي (Pro): الخادم ينادي المزوّد بمفاتيحه السرّية ضمن حدّ شهري
  modelProxy({ provider, model, system, user, temperature }) {
    return jpost("/api/model/proxy", { provider, model, system, user, temperature });
  },
};
