// shared/license.js — إدارة المستوى والصلاحيات (Pro/Free) مع مهلة سماح دون اتصال
import { settings } from "./store.js";
import { TIERS, FEATURE, FEATURE_LABEL } from "./config.js";
import { api } from "./api.js";
import { isOnline } from "./net.js";
import { toast } from "./util.js";

const GRACE_DAYS = 7; // مهلة سماح للعمل دون اتصال بعد آخر تحقّق ناجح

// الصلاحية الحالية من التخزين (افتراضي: مجاني)
export async function getEntitlement() {
  const s = await settings.get();
  const ent = s.entitlement;
  if (!ent || !ent.plan) return { plan: "free", features: TIERS.free.features, expiresAt: null, source: "default" };
  // تحقّق الانتهاء
  if (ent.expiresAt && Date.now() > ent.expiresAt) {
    return { plan: "free", features: TIERS.free.features, expiresAt: ent.expiresAt, source: "expired" };
  }
  return ent;
}

export async function getPlan() { return (await getEntitlement()).plan; }

// هل الميزة متاحة؟
export async function can(feature) {
  const ent = await getEntitlement();
  return Boolean(ent.features?.[feature]);
}

// حارس استخدام: يمنع الميزة المدفوعة ويُظهر رسالة ترقية
export async function requirePro(feature) {
  if (await can(feature)) return true;
  toast(`ميزة Pro: ${FEATURE_LABEL[feature]} — فعّل ترخيصك من ⚙ الإعدادات`, "err");
  return false;
}

export async function limit(name) {
  const ent = await getEntitlement();
  const tier = TIERS[ent.plan] || TIERS.free;
  return tier.limits?.[name];
}

// تفعيل بمفتاح ترخيص عبر الخادم
export async function activate(key) {
  const data = await api.activate(key); // {plan, features, expiresAt}
  const ent = normalize(data);
  await settings.set({ entitlement: { ...ent, lastCheck: Date.now() }, licenseKey: key });
  return ent;
}

// إعادة التحقّق (عند الإقلاع/الفتح). دون اتصال: نُبقي الصلاحية ضمن مهلة السماح.
export async function refresh() {
  const s = await settings.get();
  if (!s.auth?.token) return getEntitlement();
  if (!isOnline()) return getEntitlement();
  try {
    const data = await api.validate(); // {valid, plan, features, expiresAt}
    if (data?.valid === false) {
      await settings.set({ entitlement: { plan: "free", features: TIERS.free.features, expiresAt: null, lastCheck: Date.now() } });
      return getEntitlement();
    }
    const ent = normalize(data);
    await settings.set({ entitlement: { ...ent, lastCheck: Date.now() } });
    return ent;
  } catch {
    // فشل التحقّق (شبكة): أبقِ الصلاحية إن كنا ضمن مهلة السماح
    const ent = await getEntitlement();
    if (ent.lastCheck && Date.now() - ent.lastCheck < GRACE_DAYS * 864e5) return ent;
    return ent; // لا نُسقط فوراً؛ نترك للخادم الكلمة عند عودة الاتصال
  }
}

export async function deactivate() {
  await settings.set({ entitlement: { plan: "free", features: TIERS.free.features, expiresAt: null }, licenseKey: "" });
}

function normalize(data) {
  const plan = data?.plan === "pro" ? "pro" : "free";
  const features = data?.features || TIERS[plan].features;
  return { plan, features, expiresAt: data?.expiresAt || null, source: "server" };
}

export { FEATURE, FEATURE_LABEL };
