// shared/config.js — إعدادات مركزية: العلامة، الحقوق، المستويات، خريطة الميزات
// ⚠️ استبدل قيم المالك/الحقوق باسم جهتك قبل النشر.

export const BRAND = {
  name: "Cognita",
  tagline: "استوديو الذكاء داخل المتصفح",
  version: "2.1.1",
  owner: "Mohammed Almasqari",
  copyright: "© 2026 Mohammed Almasqari — جميع الحقوق محفوظة.",
  website: "https://cognita.dalilai.net",
  supportEmail: "support@dalilai.net",
};

// مفاتيح الميزات القابلة للقفل حسب المستوى
export const FEATURE = {
  AI_OPTIMIZE: "aiOptimize",     // تحسين البرومبت/البحث بالذكاء
  AGENT_RUN: "agentRun",         // تشغيل سلاسل الوكلاء
  AUTO_SEARCH_MULTI: "autoSearchMulti", // بحث تلقائي متعدد التبويبات
  CLOUD_SYNC: "cloudSync",       // المزامنة السحابية
};

// تعريف المستويات والميزات المتاحة لكل مستوى
export const TIERS = {
  free: {
    label: "مجاني",
    features: {
      [FEATURE.AI_OPTIMIZE]: true,   // ميزات الذكاء تعمل بمفتاح المستخدم الخاص مجاناً
      [FEATURE.AGENT_RUN]: false,
      [FEATURE.AUTO_SEARCH_MULTI]: false,
      [FEATURE.CLOUD_SYNC]: false,
    },
    limits: { autoSearchTabs: 1 },
  },
  pro: {
    label: "Pro",
    features: {
      [FEATURE.AI_OPTIMIZE]: true,
      [FEATURE.AGENT_RUN]: true,
      [FEATURE.AUTO_SEARCH_MULTI]: true,
      [FEATURE.CLOUD_SYNC]: true,
    },
    limits: { autoSearchTabs: 8 },
  },
};

// وصف الميزات المدفوعة للعرض عند القفل
export const FEATURE_LABEL = {
  [FEATURE.AI_OPTIMIZE]: "التحسين بالذكاء الاصطناعي",
  [FEATURE.AGENT_RUN]: "تشغيل الوكلاء",
  [FEATURE.AUTO_SEARCH_MULTI]: "البحث التلقائي متعدد التبويبات",
  [FEATURE.CLOUD_SYNC]: "المزامنة السحابية",
};
