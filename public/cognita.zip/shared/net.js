// shared/net.js — كشف الاتصال ومعالجة أخطاء الشبكة برسائل عربية واضحة

export const isOnline = () => (typeof navigator !== "undefined" ? navigator.onLine : true);

// خطأ مُصنّف برسالة عربية واضحة
export class AppError extends Error {
  constructor(message, kind = "generic") {
    super(message);
    this.kind = kind; // offline | auth | rate | server | bad | generic
  }
}

// تحويل استجابة/خطأ fetch إلى رسالة واضحة
export async function toAppError(resOrErr) {
  // فشل الشبكة (TypeError من fetch) أو عدم اتصال
  if (resOrErr instanceof Error) {
    if (!isOnline()) return new AppError("لا يوجد اتصال بالإنترنت. تحقّق من شبكتك وحاول مجدداً.", "offline");
    return new AppError("تعذّر الوصول إلى الخدمة. قد يكون الخادم غير متاح أو الاتصال ضعيف.", "offline");
  }
  const res = resOrErr;
  let detail = "";
  try {
    const j = await res.clone().json();
    detail = (j?.error && (j.error.message || (typeof j.error === "string" ? j.error : ""))) || j?.message || "";
  } catch {}
  if (res.status === 401 || res.status === 403)
    return new AppError(detail || "غير مُصرّح. تحقّق من تسجيل الدخول أو المفتاح.", "auth");
  if (res.status === 429)
    return new AppError(detail || "تجاوزت حد الطلبات المسموح. انتظر قليلاً ثم أعِد المحاولة.", "rate");
  if (res.status >= 500)
    return new AppError(detail || "خطأ في الخادم. حاول لاحقاً.", "server");
  return new AppError(detail || `طلب غير صالح (${res.status}).`, "bad");
}

// غلاف fetch آمن: يرمي AppError واضحاً بدل أخطاء غامضة
export async function safeFetch(url, opts = {}, timeoutMs = 30000) {
  if (!isOnline()) throw new AppError("لا يوجد اتصال بالإنترنت.", "offline");
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), timeoutMs);
  let res;
  try {
    res = await fetch(url, { ...opts, signal: ctrl.signal });
  } catch (e) {
    clearTimeout(t);
    if (e.name === "AbortError") throw new AppError("انتهت مهلة الطلب. حاول مجدداً.", "offline");
    throw await toAppError(e);
  }
  clearTimeout(t);
  if (!res.ok) throw await toAppError(res);
  return res;
}
