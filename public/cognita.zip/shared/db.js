// shared/db.js — غلاف بسيط لـ IndexedDB (بلا مكتبات خارجية)
// المخازن: prompts, flows, runs, searches

const DB_NAME = "cognita";
const DB_VERSION = 2;
let _db = null;

function open() {
  if (_db) return Promise.resolve(_db);
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = (e) => {
      const db = e.target.result;
      if (!db.objectStoreNames.contains("prompts")) {
        const s = db.createObjectStore("prompts", { keyPath: "id" });
        s.createIndex("targetModel", "targetModel", { unique: false });
        s.createIndex("updatedAt", "updatedAt", { unique: false });
      }
      if (!db.objectStoreNames.contains("flows")) {
        const s = db.createObjectStore("flows", { keyPath: "id" });
        s.createIndex("updatedAt", "updatedAt", { unique: false });
      }
      if (!db.objectStoreNames.contains("runs")) {
        const s = db.createObjectStore("runs", { keyPath: "id" });
        s.createIndex("flowId", "flowId", { unique: false });
      }
      if (!db.objectStoreNames.contains("searches")) {
        const s = db.createObjectStore("searches", { keyPath: "id" });
        s.createIndex("updatedAt", "updatedAt", { unique: false });
      }
      if (!db.objectStoreNames.contains("clippings")) {
        const s = db.createObjectStore("clippings", { keyPath: "id" });
        s.createIndex("updatedAt", "updatedAt", { unique: false });
      }
    };
    req.onsuccess = () => { _db = req.result; resolve(_db); };
    req.onerror = () => reject(req.error);
  });
}

function tx(store, mode) {
  return open().then((db) => db.transaction(store, mode).objectStore(store));
}

export const db = {
  async put(store, value) {
    const os = await tx(store, "readwrite");
    return new Promise((res, rej) => {
      const r = os.put(value);
      r.onsuccess = () => res(value);
      r.onerror = () => rej(r.error);
    });
  },
  async get(store, id) {
    const os = await tx(store, "readonly");
    return new Promise((res, rej) => {
      const r = os.get(id);
      r.onsuccess = () => res(r.result || null);
      r.onerror = () => rej(r.error);
    });
  },
  async all(store) {
    const os = await tx(store, "readonly");
    return new Promise((res, rej) => {
      const r = os.getAll();
      r.onsuccess = () => res(r.result || []);
      r.onerror = () => rej(r.error);
    });
  },
  async del(store, id) {
    const os = await tx(store, "readwrite");
    return new Promise((res, rej) => {
      const r = os.delete(id);
      r.onsuccess = () => res(true);
      r.onerror = () => rej(r.error);
    });
  },
  async clear(store) {
    const os = await tx(store, "readwrite");
    return new Promise((res, rej) => {
      const r = os.clear();
      r.onsuccess = () => res(true);
      r.onerror = () => rej(r.error);
    });
  },
};

// أدوات مساعدة عامة
export const uid = () =>
  Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
export const now = () => Date.now();
