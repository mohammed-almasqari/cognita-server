// shared/providers.js — مُحوّلات استدعاء النماذج (تعمل بمفتاح المستخدم محلياً)
// تُستدعى من سياق صفحة الإضافة (panel/options) حيث تتوفّر host_permissions.

import { settings } from "./store.js";
import { safeFetch, isOnline, AppError } from "./net.js";
import { api } from "./api.js";

export const PROVIDERS = {
  openai: {
    label: "OpenAI",
    models: ["gpt-4o", "gpt-4o-mini", "gpt-4-turbo", "o1-mini"],
    keyHint: "sk-...",
    keysUrl: "https://platform.openai.com/api-keys",
  },
  anthropic: {
    label: "Anthropic (Claude)",
    models: ["claude-3-5-sonnet-latest", "claude-3-5-haiku-latest", "claude-3-opus-latest"],
    keyHint: "sk-ant-...",
    keysUrl: "https://console.anthropic.com/settings/keys",
  },
  gemini: {
    label: "Google Gemini",
    models: ["gemini-1.5-pro", "gemini-1.5-flash", "gemini-2.0-flash-exp"],
    keyHint: "AIza...",
    keysUrl: "https://aistudio.google.com/app/apikey",
  },
  groq: {
    label: "Groq",
    models: ["llama-3.3-70b-versatile", "llama-3.1-8b-instant", "mixtral-8x7b-32768"],
    keyHint: "gsk_...",
    keysUrl: "https://console.groq.com/keys",
    openaiCompat: "https://api.groq.com/openai/v1/chat/completions",
  },
  openrouter: {
    label: "OpenRouter",
    models: ["openai/gpt-4o-mini", "anthropic/claude-3.5-sonnet", "google/gemini-flash-1.5", "meta-llama/llama-3.1-70b-instruct"],
    keyHint: "sk-or-...",
    keysUrl: "https://openrouter.ai/keys",
    openaiCompat: "https://openrouter.ai/api/v1/chat/completions",
  },
  deepseek: {
    label: "DeepSeek",
    models: ["deepseek-chat", "deepseek-reasoner"],
    keyHint: "sk-...",
    keysUrl: "https://platform.deepseek.com/api_keys",
    openaiCompat: "https://api.deepseek.com/chat/completions",
  },
};

// النداء الموحّد: يعيد نصاً أو يرمي خطأً واضحاً
export async function callModel({ provider, model, system, user, temperature = 0.5 }) {
  const s = await settings.get();
  provider = provider || s.defaultProvider;
  model = model || s.models[provider];
  if (!isOnline()) {
    throw new AppError("لا يوجد اتصال بالإنترنت — لا يمكن استدعاء النموذج الآن.", "offline");
  }

  // المسار 1: وكيل الخادم المركزي (Pro) — يستخدم مفاتيح الخادم السرّية ضمن حدّ شهري.
  // لا يحتاج المستخدم لمفتاحه الخاص. المزوّد والنموذج يحدّدهما الخادم (إعداد المشرف) — لا نرسلهما.
  if (s.useServerProxy) {
    if (!s.backendUrl || !s.auth?.token) {
      throw new AppError("وكيل خادم Cognita مُفعّل لكنك لم تسجّل الدخول للخادم. سجّل الدخول من الإعدادات ← الحساب، أو عطّل وكيل الخادم لاستخدام مفتاحك الخاص.", "auth");
    }
    const data = await api.modelProxy({ system, user, temperature });
    return (data?.text || "").trim();
  }

  // المسار 2: مفتاح المستخدم محلياً (BYO key) — النداء المباشر للمزوّد.
  const key = s.keys?.[provider];
  if (!key) {
    throw new AppError(`لا يوجد مفتاح API لمزوّد ${PROVIDERS[provider].label}. أضِفه من الإعدادات، أو فعّل وكيل خادم Cognita (Pro).`, "bad");
  }
  if (provider === "openai") return openai({ key, model, system, user, temperature });
  if (provider === "anthropic") return anthropic({ key, model, system, user, temperature });
  if (provider === "gemini") return gemini({ key, model, system, user, temperature });
  if (PROVIDERS[provider]?.openaiCompat) return openaiCompatible({ url: PROVIDERS[provider].openaiCompat, key, model, system, user, temperature });
  throw new Error("مزوّد غير معروف: " + provider);
}

// مزوّدون متوافقون مع واجهة OpenAI (Groq, OpenRouter, DeepSeek…)
async function openaiCompatible({ url, key, model, system, user, temperature }) {
  const res = await safeFetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` },
    body: JSON.stringify({
      model, temperature,
      messages: [...(system ? [{ role: "system", content: system }] : []), { role: "user", content: user }],
    }),
  });
  const data = await res.json();
  return data.choices?.[0]?.message?.content?.trim() || "";
}

async function openai({ key, model, system, user, temperature }) {
  const res = await safeFetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` },
    body: JSON.stringify({
      model,
      temperature,
      messages: [
        ...(system ? [{ role: "system", content: system }] : []),
        { role: "user", content: user },
      ],
    }),
  });
  const data = await res.json();
  return data.choices?.[0]?.message?.content?.trim() || "";
}

async function anthropic({ key, model, system, user, temperature }) {
  const res = await safeFetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": key,
      "anthropic-version": "2023-06-01",
      "anthropic-dangerous-direct-browser-access": "true",
    },
    body: JSON.stringify({
      model,
      max_tokens: 2048,
      temperature,
      ...(system ? { system } : {}),
      messages: [{ role: "user", content: user }],
    }),
  });
  const data = await res.json();
  return (data.content || []).map((b) => b.text || "").join("").trim();
}

async function gemini({ key, model, system, user, temperature }) {
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${encodeURIComponent(key)}`;
  const res = await safeFetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      ...(system ? { systemInstruction: { parts: [{ text: system }] } } : {}),
      contents: [{ role: "user", parts: [{ text: user }] }],
      generationConfig: { temperature },
    }),
  });
  const data = await res.json();
  return (data.candidates?.[0]?.content?.parts || []).map((p) => p.text || "").join("").trim();
}
