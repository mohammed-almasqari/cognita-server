// shared/util.js — أدوات DOM ونصوص مشتركة

export const $ = (sel, root = document) => root.querySelector(sel);
export const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];

export function el(tag, props = {}, children = []) {
  const node = document.createElement(tag);
  for (const [k, v] of Object.entries(props)) {
    if (k === "class") node.className = v;
    else if (k === "html") node.innerHTML = v;
    else if (k === "text") node.textContent = v;
    else if (k.startsWith("on") && typeof v === "function")
      node.addEventListener(k.slice(2).toLowerCase(), v);
    else if (v !== null && v !== undefined) node.setAttribute(k, v);
  }
  for (const c of [].concat(children)) {
    if (c == null) continue;
    node.append(c.nodeType ? c : document.createTextNode(c));
  }
  return node;
}

export const esc = (s = "") =>
  String(s).replace(/[&<>"']/g, (c) =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c])
  );

// استخراج المتغيرات {{...}} من نص
export function extractVars(text = "") {
  const set = new Map();
  const re = /\{\{\s*([^}]+?)\s*\}\}/g;
  let m;
  while ((m = re.exec(text))) {
    const key = m[1].trim();
    if (!set.has(key)) set.set(key, { key, type: "text" });
  }
  return [...set.values()];
}

// تعويض المتغيرات بقيمها
export function fillVars(text = "", values = {}) {
  return text.replace(/\{\{\s*([^}]+?)\s*\}\}/g, (_, k) => {
    const key = k.trim();
    return values[key] != null && values[key] !== "" ? values[key] : `{{${key}}}`;
  });
}

// تقدير عدد الرموز (تقريبي client-side)
export function estimateTokens(text = "") {
  const chars = text.length;
  const words = (text.trim().match(/\S+/g) || []).length;
  return Math.max(Math.round(chars / 4), Math.round(words * 1.3));
}

// إشعار عائم
let toastTimer;
export function toast(msg, kind = "info") {
  let t = $("#cognita-toast");
  if (!t) {
    t = el("div", { id: "cognita-toast" });
    document.body.append(t);
  }
  t.textContent = msg;
  t.className = "show " + kind;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => (t.className = ""), 2600);
}

export async function copyText(text) {
  try {
    await navigator.clipboard.writeText(text);
    toast("تم النسخ ✓", "ok");
  } catch {
    toast("تعذّر النسخ", "err");
  }
}

export const fmtTime = (ts) =>
  new Date(ts).toLocaleString("ar", { dateStyle: "medium", timeStyle: "short" });
