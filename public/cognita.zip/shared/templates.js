// shared/templates.js — قوالب بداية محايدة المزوّد + بنية تفضيلية لكل نموذج

export const MODEL_STYLES = {
  openai: {
    name: "GPT-4 / 4o",
    tip: "رسالة نظام واضحة + تعليمات مرقّمة + تحديد صيغة المخرَج بدقة.",
    wrap: (p) =>
      `# الدور\n${p.role || "مساعد خبير"}\n\n# المهمة\n${p.task}\n\n# القيود\n${p.constraints || "اذكر القيود بوضوح"}\n\n# صيغة المخرَج\n${p.format || "نص منظّم"}`,
  },
  anthropic: {
    name: "Claude",
    tip: "وسوم XML منظّمة وبنية صريحة وأمثلة قليلة.",
    wrap: (p) =>
      `<role>${p.role || "مساعد خبير"}</role>\n<context>\n${p.context || p.task}\n</context>\n<instructions>\n${p.task}\n</instructions>\n<constraints>${p.constraints || ""}</constraints>\n<output_format>${p.format || "نص منظّم"}</output_format>`,
  },
  gemini: {
    name: "Gemini",
    tip: "تعليمات مباشرة موجزة + أمثلة + تحديد اللغة.",
    wrap: (p) =>
      `التعليمات: ${p.role || "تصرّف كمساعد خبير"}.\nالمهمة: ${p.task}\nالقيود: ${p.constraints || "—"}\nالصيغة المطلوبة: ${p.format || "نص منظّم"}`,
  },
  llama: {
    name: "Llama",
    tip: "تعليمات نظام مختصرة ضمن قالب المحادثة.",
    wrap: (p) =>
      `<|system|>\n${p.role || "مساعد خبير"}\n<|user|>\n${p.task}\nالقيود: ${p.constraints || "—"}`,
  },
  mistral: {
    name: "Mistral",
    tip: "تعليمات مكثّفة مباشرة بلا حشو.",
    wrap: (p) =>
      `[INST] ${p.role || "مساعد خبير"}\nالمهمة: ${p.task}\nالقيود: ${p.constraints || "—"} [/INST]`,
  },
};

// قوالب جاهزة في المكتبة عند أول تشغيل
export const SEED_PROMPTS = [
  {
    title: "كاتب محتوى تسويقي",
    targetModel: "openai",
    body:
      "# الدور\nأنت كاتب محتوى تسويقي محترف باللغة {{اللغة}}.\n\n# المهمة\nاكتب {{نوع_المحتوى}} عن {{الموضوع}} موجّهاً لـ {{الجمهور}}.\n\n# النبرة\n{{النبرة}}\n\n# صيغة المخرَج\nعنوان جذّاب + ٣ فقرات + دعوة لإجراء.",
    tags: ["تسويق", "كتابة"],
  },
  {
    title: "محلّل ومُلخّص نصوص",
    targetModel: "anthropic",
    body:
      "<role>محلّل خبير</role>\n<context>\n{{النص}}\n</context>\n<instructions>\nلخّص النص في {{عدد_النقاط}} نقاط رئيسية، ثم استخرج أهم رؤية واحدة.\n</instructions>\n<output_format>قائمة نقطية ثم سطر «الرؤية:»</output_format>",
    tags: ["تحليل", "تلخيص"],
  },
  {
    title: "مساعد برمجي — مراجعة كود",
    targetModel: "openai",
    body:
      "# الدور\nمهندس برمجيات أول متخصص في {{اللغة_البرمجية}}.\n\n# المهمة\nراجع الكود التالي واذكر: الأخطاء، مشاكل الأداء، وتحسينات الأمان.\n\n```\n{{الكود}}\n```\n\n# صيغة المخرَج\nجدول: المشكلة | الخطورة | الإصلاح المقترح.",
    tags: ["برمجة", "مراجعة"],
  },
];
