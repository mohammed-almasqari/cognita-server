// shared/store.js — إدارة الإعدادات والمفاتيح عبر chrome.storage.local
// المفاتيح تُحفظ محلياً فقط ولا تُزامن سحابياً.

const DEFAULTS = {
  theme: "light",            // light | dark
  lang: "ar",                // ar | en
  defaultProvider: "openai", // openai | anthropic | gemini
  models: {
    openai: "gpt-4o",
    anthropic: "claude-3-5-sonnet-latest",
    gemini: "gemini-1.5-pro",
    local: "qwen2.5:3b",
  },
  localModels: [],           // النماذج المحلية المكتشَفة فعلياً من Ollama (/api/tags)
  keys: {                    // مفاتيح API — محلية فقط
    openai: "",
    anthropic: "",
    gemini: "",
  },
  // الطبقة الخلفية والترخيص — موصولة مسبقاً بخادم Cognita الرسمي (يمكن تغييره للمستضيف الذاتي)
  backendUrl: "https://cognita.dalilai.net",
  auth: { token: "", email: "" },
  licenseKey: "",
  entitlement: null,         // { plan, features, expiresAt, lastCheck }
  // وكيل النماذج المركزي: عند تفعيله يستخدم مشترك Pro مفاتيح الخادم بدل مفتاحه الخاص
  useServerProxy: false,
};

export const settings = {
  async get() {
    const data = await chrome.storage.local.get("settings");
    return deepMerge(structuredClone(DEFAULTS), data.settings || {});
  },
  async set(patch) {
    const cur = await this.get();
    const next = deepMerge(cur, patch);
    await chrome.storage.local.set({ settings: next });
    return next;
  },
  async hasKey(provider) {
    const s = await this.get();
    return Boolean(s.keys?.[provider]);
  },
  defaults: DEFAULTS,
};

function deepMerge(base, patch) {
  for (const k of Object.keys(patch || {})) {
    if (patch[k] && typeof patch[k] === "object" && !Array.isArray(patch[k])) {
      base[k] = deepMerge(base[k] || {}, patch[k]);
    } else {
      base[k] = patch[k];
    }
  }
  return base;
}

// جسر مؤقت للتواصل بين قائمة السياق واللوحة
export const bridge = {
  async send(action, payload) {
    await chrome.storage.local.set({ __pending: { action, payload, t: Date.now() } });
  },
  async take() {
    const d = await chrome.storage.local.get("__pending");
    if (d.__pending) {
      await chrome.storage.local.remove("__pending");
      return d.__pending;
    }
    return null;
  },
};
