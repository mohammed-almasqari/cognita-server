// options/options.js — صفحة الإعدادات
import { settings } from "../shared/store.js";
import { PROVIDERS } from "../shared/providers.js";
import { db } from "../shared/db.js";
import { $, $$, toast } from "../shared/util.js";
import { api, ensureHostPermission } from "../shared/api.js";
import { activate as activateLicense, getEntitlement, refresh as refreshLicense } from "../shared/license.js";
import { BRAND } from "../shared/config.js";

let s;

async function init() {
  s = await settings.get();
  document.documentElement.setAttribute("data-theme", s.theme);

  // المزودون
  $("#providers").innerHTML = Object.entries(PROVIDERS).map(([k, p]) => `
    <div class="prov" data-prov="${k}">
      <div class="prov-top">
        <span class="nm">${p.label}</span>
        <a href="${p.keysUrl}" target="_blank" rel="noopener noreferrer" class="small">الحصول على مفتاح ↗</a>
      </div>
      <div class="keyrow">
        <input type="password" data-key="${k}" placeholder="${p.keyHint}" value="${s.keys?.[k] || ""}">
        <button class="btn sm" data-toggle="${k}">👁</button>
      </div>
      <div class="field" style="margin-top:8px"><label>النموذج</label>
        <select data-model="${k}">${p.models.map((m) => `<option value="${m}" ${s.models?.[k] === m ? "selected" : ""}>${m}</option>`).join("")}</select>
      </div>
    </div>`).join("");

  // المزوّد الافتراضي
  $("#def-provider").innerHTML = Object.entries(PROVIDERS)
    .map(([k, p]) => `<option value="${k}" ${s.defaultProvider === k ? "selected" : ""}>${p.label}</option>`).join("");
  $("#theme").value = s.theme;
  $("#backend-url").value = s.backendUrl || "";
  setupModeSwitch(s);

  // إظهار/إخفاء المفتاح
  $$("[data-toggle]").forEach((b) => (b.onclick = () => {
    const inp = $(`[data-key="${b.dataset.toggle}"]`);
    inp.type = inp.type === "password" ? "text" : "password";
  }));

  wireAccount();
  renderAbout();
  await renderAccount();
}

// مبدّل مصدر النماذج (3 أوضاع): مفتاحي الخاص (مجاني) | نموذج محلي Ollama (مجاني وخاص) | خادم Cognita (Pro) — يُحفظ فوراً
function setupModeSwitch(s) {
  const note = $("#mode-note");
  const modeOf = (st) => st.useServerProxy ? "server" : (st.defaultProvider === "local" ? "ollama" : "byok");
  const render = (mode) => {
    $("#mode-byok").classList.toggle("on", mode === "byok");
    $("#mode-ollama").classList.toggle("on", mode === "ollama");
    $("#mode-server").classList.toggle("on", mode === "server");
    note.innerHTML = mode === "server"
      ? "🛡️ نماذج خادم Cognita بمفاتيحنا — يتطلّب اشتراك Pro وتسجيل الدخول للخادم. لا حاجة لمفتاح."
      : mode === "ollama"
      ? "🖥️ نموذج يعمل على جهازك عبر <b>Ollama</b> — مجاني وخاص وبلا API مدفوع. ثبّت Ollama ونزّل نموذجاً (راجع الدليل)، وتأكّد من ضبط <code>OLLAMA_ORIGINS=*</code>."
      : "🔑 تستخدم مفتاح API الخاص بك (مجاناً) — أدخِله بالأسفل، وتعمل ميزات الذكاء مباشرةً.";
  };
  render(modeOf(s));
  $("#mode-byok").onclick = async () => {
    const cur = await settings.get();
    const patch = { useServerProxy: false };
    if (cur.defaultProvider === "local") patch.defaultProvider = "openai";
    await settings.set(patch); render("byok"); toast("المصدر: مفتاحك الخاص ✓", "ok");
  };
  $("#mode-ollama").onclick = async () => { await settings.set({ useServerProxy: false, defaultProvider: "local" }); render("ollama"); toast("المصدر: نموذج محلي (Ollama) ✓", "ok"); };
  $("#mode-server").onclick = async () => { await settings.set({ useServerProxy: true }); render("server"); toast("المصدر: خادم Cognita ✓", "ok"); };
}

// ===== الحساب والترخيص =====
async function renderAccount() {
  s = await settings.get();
  const inn = Boolean(s.auth?.token);
  $("#acct-loggedout").hidden = inn;
  $("#acct-loggedin").hidden = !inn;
  if (inn) {
    const ent = await getEntitlement();
    $("#acct-who").textContent = s.auth.email || "مستخدم";
    const planEl = $("#acct-plan");
    planEl.textContent = ent.plan === "pro" ? "Pro ✦" : "مجاني";
    planEl.className = "pill " + (ent.plan === "pro" ? "a" : "n");
    $("#license-key").value = s.licenseKey || "";
  }
}

async function saveBackendUrl() {
  const url = $("#backend-url").value.trim().replace(/\/+$/, "");
  await settings.set({ backendUrl: url });
  if (url) await ensureHostPermission(url);
  return url;
}

async function withBtn(btn, fn) {
  const old = btn.innerHTML; btn.disabled = true; btn.innerHTML = '<span class="spin"></span>';
  try { await fn(); } catch (e) { toast(e.message || "حدث خطأ", "err"); }
  finally { btn.disabled = false; btn.innerHTML = old; }
}

function wireAccount() {
  $("#acct-login").onclick = (e) => withBtn(e.currentTarget, async () => {
    const url = await saveBackendUrl();
    if (!url) return toast("أدخِل رابط الخادم أولاً", "err");
    await api.login($("#acct-email").value.trim(), $("#acct-pass").value);
    await refreshLicense(); toast("تم تسجيل الدخول ✓", "ok"); await renderAccount();
  });
  $("#acct-register").onclick = (e) => withBtn(e.currentTarget, async () => {
    const url = await saveBackendUrl();
    if (!url) return toast("أدخِل رابط الخادم أولاً", "err");
    await api.register($("#acct-email").value.trim(), $("#acct-pass").value);
    await refreshLicense(); toast("تم إنشاء الحساب ✓", "ok"); await renderAccount();
  });
  $("#license-activate").onclick = (e) => withBtn(e.currentTarget, async () => {
    const key = $("#license-key").value.trim();
    if (!key) return toast("أدخِل مفتاح الترخيص", "err");
    const ent = await activateLicense(key);
    toast(`تم التفعيل: ${ent.plan === "pro" ? "Pro" : "مجاني"} ✓`, "ok"); await renderAccount();
  });
  $("#acct-logout").onclick = (e) => withBtn(e.currentTarget, async () => {
    await api.logout(); toast("تم تسجيل الخروج", "ok"); await renderAccount();
  });
  $("#acct-sync-push").onclick = (e) => withBtn(e.currentTarget, async () => {
    const payload = { prompts: await db.all("prompts"), flows: await db.all("flows"), searches: await db.all("searches") };
    await api.syncPush(payload); toast("تم رفع المكتبة للسحابة ✓", "ok");
  });
  $("#acct-sync-pull").onclick = (e) => withBtn(e.currentTarget, async () => {
    const data = await api.syncPull();
    for (const st of ["prompts", "flows", "searches"]) for (const r of data[st] || []) await db.put(st, r);
    toast("تم جلب البيانات من السحابة ✓", "ok");
  });
}

function renderAbout() {
  $("#about-box").innerHTML = `
    <div><b>${BRAND.name}</b> — ${BRAND.tagline}</div>
    <div>الإصدار: <code>${BRAND.version}</code></div>
    <div>المالك: ${BRAND.owner}</div>
    <div>${BRAND.copyright}</div>
    <div>الموقع: <a href="${BRAND.website}" target="_blank" rel="noopener noreferrer">${BRAND.website}</a></div>
    <div>الدعم: ${BRAND.supportEmail}</div>`;
}

$("#save").onclick = async () => {
  const keys = {}, models = {};
  $$("[data-key]").forEach((i) => (keys[i.dataset.key] = i.value.trim()));
  $$("[data-model]").forEach((i) => (models[i.dataset.model] = i.value));
  await settings.set({
    keys, models,
    defaultProvider: $("#def-provider").value,
    theme: $("#theme").value,
    backendUrl: $("#backend-url").value.trim().replace(/\/+$/, ""),
  });
  document.documentElement.setAttribute("data-theme", $("#theme").value);
  $("#saved-msg").textContent = "✓ حُفظت الإعدادات";
  toast("حُفظت الإعدادات ✓", "ok");
  setTimeout(() => ($("#saved-msg").textContent = ""), 2500);
};

// تصدير
$("#export").onclick = async () => {
  const data = {
    _app: "cognita", _v: 1, exportedAt: Date.now(),
    prompts: await db.all("prompts"),
    flows: await db.all("flows"),
    searches: await db.all("searches"),
  };
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = `cognita-backup-${new Date().toISOString().slice(0, 10)}.json`;
  a.click(); URL.revokeObjectURL(url);
  toast("تم التصدير ✓", "ok");
};

// استيراد
$("#import-btn").onclick = () => $("#import-file").click();
$("#import-file").onchange = async (e) => {
  const file = e.target.files[0]; if (!file) return;
  try {
    const data = JSON.parse(await file.text());
    if (data._app !== "cognita") throw new Error("ملف غير متوافق");
    for (const store of ["prompts", "flows", "searches"]) {
      for (const rec of data[store] || []) await db.put(store, rec);
    }
    toast("تم الاستيراد ✓", "ok");
  } catch (err) { toast("فشل الاستيراد: " + err.message, "err"); }
  e.target.value = "";
};

// مسح
$("#clear").onclick = async () => {
  if (!confirm("سيُمسح كل البرومبت والسلاسل وعمليات البحث المحفوظة. متابعة؟")) return;
  await db.clear("prompts"); await db.clear("flows"); await db.clear("searches");
  toast("مُسحت البيانات", "ok");
};

init();
