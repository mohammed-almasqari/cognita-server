// popup/popup.js — وصول سريع: يفتح اللوحة على الوحدة المطلوبة
import { settings, bridge } from "../shared/store.js";
import { PROVIDERS } from "../shared/providers.js";

async function openPanel(action) {
  // أرسِل النية بالتوازي (بلا await) لإبقاء فتح اللوحة ضمن إيماءة المستخدم
  bridge.send(action, {});
  try {
    const win = await chrome.windows.getCurrent();
    await chrome.sidePanel.open({ windowId: win.id });
    window.close();
  } catch (e) {
    // بديل: افتح اللوحة كصفحة كاملة مع تمرير الوحدة المطلوبة
    chrome.tabs.create({ url: chrome.runtime.getURL("panel/panel.html?tab=" + action) });
    window.close();
  }
}

document.querySelectorAll("[data-open]").forEach((b) =>
  (b.onclick = () => openPanel(b.dataset.open))
);

// زر سريع: إصلاح اتجاه العربية على الموقع الحالي
const rtlQuick = document.getElementById("rtl-quick");
if (rtlQuick) rtlQuick.onclick = async () => {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id) return;
    chrome.tabs.sendMessage(tab.id, { type: "RTL_TOGGLE" }, (r) => {
      if (chrome.runtime.lastError) return;
      window.close();
    });
  } catch (e) { /* تجاهل */ }
};

document.getElementById("pop-settings").onclick = () => {
  chrome.runtime.openOptionsPage();
  window.close();
};

// مؤشّر حالة المفاتيح
(async () => {
  const s = await settings.get();
  const configured = Object.entries(s.keys || {}).filter(([, v]) => v).map(([k]) => PROVIDERS[k].label);
  const stat = document.getElementById("keystat");
  if (configured.length) {
    stat.innerHTML = `<b style="background:var(--search)"></b> مفعّل: ${configured.join("، ")}`;
  } else {
    stat.innerHTML = `<b style="background:var(--amber)"></b> أضِف مفتاح API للتفعيل`;
  }
})();
