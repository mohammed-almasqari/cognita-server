// background/service-worker.js — الموجّه المركزي (Manifest V3, module)
import { bridge } from "../shared/store.js";
import { db, uid, now } from "../shared/db.js";
import { SEED_PROMPTS } from "../shared/templates.js";

const MENU = {
  optimize: "cognita_optimize",
  search: "cognita_search",
  agent: "cognita_agent",
};

chrome.runtime.onInstalled.addListener(async (details) => {
  // قوائم السياق
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({ id: MENU.optimize, title: "Cognita: حسّن كبرومبت ✦", contexts: ["selection"] });
    chrome.contextMenus.create({ id: MENU.search, title: "Cognita: ابحث بذكاء 🔍", contexts: ["selection"] });
    chrome.contextMenus.create({ id: MENU.agent, title: "Cognita: أرسِل للوكيل ◉", contexts: ["selection"] });
  });

  // زرع قوالب البداية عند أول تثبيت
  if (details.reason === "install") {
    try {
      const existing = await db.all("prompts");
      if (!existing.length) {
        for (const p of SEED_PROMPTS) {
          await db.put("prompts", {
            id: uid(), createdAt: now(), updatedAt: now(), version: 1,
            favorite: false, variables: [], ...p,
          });
        }
      }
    } catch (e) { console.warn("seed failed", e); }
  }
});

// النقر على عنصر قائمة السياق → خزّن النية وافتح اللوحة
// ملاحظة: نفتح اللوحة ضمن سياق الإيماءة (بلا await قبلها) ونرسل النية بالتوازي،
// واللوحة تلتقط النية عبر مستمع chrome.storage.onChanged.
chrome.contextMenus.onClicked.addListener((info, tab) => {
  const text = info.selectionText || "";
  let action = "prompt";
  if (info.menuItemId === MENU.search) action = "search";
  else if (info.menuItemId === MENU.agent) action = "agent";
  bridge.send(action, { text });
  if (tab?.windowId != null) {
    chrome.sidePanel.open({ windowId: tab.windowId }).catch((e) => console.warn(e));
  }
});

// رسائل من سكربت المحتوى أو الواجهات
chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  if (msg?.type === "OPEN_PANEL") {
    const wid = sender.tab?.windowId;
    if (wid != null) chrome.sidePanel.open({ windowId: wid }).catch(() => {});
    reply?.({ ok: true });
  }
  if (msg?.type === "PUSH_INTENT") {
    bridge.send(msg.action || "prompt", { text: msg.text || "" });
    reply?.({ ok: true });
  }
  return true;
});
