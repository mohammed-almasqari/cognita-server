// panel/panel.js — متحكم اللوحة الجانبية
import { settings, bridge } from "../shared/store.js";
import { $, $$ } from "../shared/util.js";
import { getEntitlement, refresh } from "../shared/license.js";
import { isOnline } from "../shared/net.js";
import * as chatMod from "../modules/chat.js";
import * as promptMod from "../modules/prompt.js";
import * as agentsMod from "../modules/agents.js";
import * as searchMod from "../modules/search.js";
import * as pageMod from "../modules/pagetools.js";

const MODULES = { chat: chatMod, prompt: promptMod, agents: agentsMod, search: searchMod, pagetools: pageMod };
const view = $("#view");
let activeTab = "chat";

async function applyTheme() {
  const s = await settings.get();
  document.documentElement.setAttribute("data-theme", s.theme);
}

async function showTab(tab, intent = null) {
  activeTab = tab;
  $$(".tab").forEach((t) => t.classList.toggle("active", t.dataset.tab === tab));
  view.innerHTML = "";
  view.scrollTop = 0;
  await MODULES[tab].mount(view, intent);
}

// التنقل بين التبويبات
$$(".tab").forEach((t) => (t.onclick = () => showTab(t.dataset.tab)));

// الثيم والإعدادات
$("#btn-theme").onclick = async () => {
  const s = await settings.get();
  await settings.set({ theme: s.theme === "dark" ? "light" : "dark" });
  applyTheme();
};
$("#btn-settings").onclick = () => chrome.runtime.openOptionsPage();
$("#plan-badge").onclick = () => chrome.runtime.openOptionsPage();

// شارة الخطة
async function updatePlanBadge() {
  const ent = await getEntitlement();
  const badge = $("#plan-badge");
  const pro = ent.plan === "pro";
  badge.textContent = pro ? "Pro ✦" : "مجاني";
  badge.className = "plan-badge " + (pro ? "pro" : "free");
}

// شريط عدم الاتصال
function updateOnline() {
  const b = $("#offline-banner");
  if (b) b.hidden = isOnline();
}
window.addEventListener("online", updateOnline);
window.addEventListener("offline", updateOnline);

// التقاط النية الواردة (من قائمة السياق / الزر العائم)
function routeFromAction(action) {
  if (action === "search") return "search";
  if (action === "agent") return "agents";
  if (action === "pagetools") return "pagetools";
  return "prompt";
}

(async function init() {
  await applyTheme();
  updateOnline();
  await updatePlanBadge();
  // إعادة التحقّق من الترخيص في الخلفية ثم تحديث الشارة
  refresh().then(updatePlanBadge).catch(() => {});
  // توجيه احتياطي عند الفتح كصفحة كاملة: panel.html?tab=agents
  const urlTab = new URLSearchParams(location.search).get("tab");
  const pending = await bridge.take();
  if (pending) {
    await showTab(routeFromAction(pending.action), pending.payload);
  } else if (urlTab && MODULES[urlTab]) {
    await showTab(urlTab);
  } else {
    await showTab("chat");
  }
})();

// استقبال نية جديدة أثناء فتح اللوحة
chrome.storage.onChanged.addListener(async (changes, area) => {
  if (area !== "local") return;
  // تحديث شارة الخطة فوراً عند تفعيل ترخيص/تسجيل دخول من صفحة الإعدادات
  if (changes.settings) { updatePlanBadge().catch(() => {}); updateOnline(); }
  if (changes.__pending?.newValue) {
    const p = await bridge.take();
    if (p) await showTab(routeFromAction(p.action), p.payload);
  }
});
